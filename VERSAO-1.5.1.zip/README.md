# Master Notas

Bloco de notas para Android inspirado no Samsung Notes, feito em Flutter.

## Como atualizar (só subir o zip)

1. Receba o zip com o nome `VERSAO-x.y.z.zip` (ex.: `VERSAO-1.1.0.zip`).
2. No repositório: **Add file → Upload files**, suba o zip **sem extrair** (na raiz, junto do `pubspec.yaml`) e dê *Commit changes*.
3. O GitHub extrai o zip por cima dos arquivos, apaga o zip e compila sozinho (aba **Actions**, uns 5 minutos).
4. O APK fica em **Releases** (`MasterNotas-x.y.z.apk`) e também em Actions → compilação → *Artifacts*.
5. Baixe e instale no celular. Instala por cima, sem perder as notas (a chave de assinatura é fixa, em `ci/debug.keystore`).

Obs.: só zips com nome `VERSAO-*.zip` são aplicados. A pasta `.github` e a pasta `ci` nunca são alteradas pelo zip; se o `build.yml` mudar, edite-o à mão no GitHub.
O número da versão vem do `pubspec.yaml` (linha `version:`).

## Widget com qualquer nota (1.5.1)

O widget agora aceita qualquer nota (texto, lista ou desenho). Em notas de lista, tocar no item marca/desmarca.

## Configurações e backup em pasta (1.5.0)

Menu ⋮ → **Configurações** (estilo Samsung Notes): backup em pasta, Google Drive, salvar/restaurar backup, grade, lixeira.
**Backup em pasta**: escolha uma pasta no seletor do Android (uma vez só, pode ser dentro do Google Drive). O app grava sozinho `MasterNotas-backup.json` nela a cada alteração. Não precisa de login nem de permissão extra.

## Google Drive (1.4.0)

Menu ⋮ → **Google Drive**: login com a conta Google e sincronização automática das notas entre aparelhos (pasta privada do app no Drive).
Precisa criar um projeto grátis no Google Cloud uma vez só: veja `docs/google-drive.md`.
Requer a permissão de internet, instalada pelo `native/setup.sh` (passo "Instalar código nativo" do `build.yml`).

## Capas (1.3.0)

Dentro da nota: menu ⋮ → **Capa da nota** (ou o ícone de quadro na barra de baixo). Há 12 capas em degradê. A capa aparece como faixa colorida no topo do cartão na lista e no topo da nota.

## Widget de lista de tarefas (1.2.0)

Na tela inicial do celular: segure em um espaço vazio → **Widgets** → **Master Notas** → arraste o widget. Ele pergunta qual nota com lista de tarefas mostrar (só aparecem notas que têm pelo menos um item de lista).
Tocar em um item marca/desmarca sem abrir o app. Tocar no título abre o app. Se você mudar a nota no app, o widget atualiza sozinho.

O widget é código nativo Android: fica em `native/` e é instalado no projeto pelo workflow (`native/setup.sh`).

## O que tem na 1.1.0

- Notas com título, texto e **lista de tarefas** (Enter cria novo item; Enter em item vazio sai da lista)
- **Desenho à mão livre** (caneta, marca-texto, borracha, desfazer/refazer)
- Pastas, **fixar**, **cor da nota**, grade/lista, busca
- Seleção múltipla (segurar um cartão): fixar, mover, excluir
- **Lixeira** (apaga sozinha após 30 dias)
- Tema claro/escuro automático
- Backup: menu ⋮ → *Salvar backup* (abre o compartilhar do Android: Google Drive, OneDrive, WhatsApp, e-mail...) e *Restaurar backup* (escolhe o arquivo .json)

Tudo é salvo só no aparelho (arquivo `master_notas.json`).

## Estrutura

- `lib/` código do app
- `.github/workflows/build.yml` compilação automática
- `ci/debug.keystore` chave fixa de assinatura
- `assets/android-icons/` ícone do app (copiado para o projeto Android na compilação)
