package com.rodrigo.master_notas;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.content.UriPermission;
import android.provider.DocumentsContract;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/**
 * Le e grava um arquivo numa pasta escolhida pelo usuario no seletor do Android
 * (Storage Access Framework). A permissao da pasta fica guardada pelo sistema,
 * entao nao precisa abrir o seletor de novo.
 */
final class FolderAccess {
    private FolderAccess() {
    }

    static String displayName(Context ctx, Uri tree) {
        try {
            String docId = DocumentsContract.getTreeDocumentId(tree);
            Uri doc = DocumentsContract.buildDocumentUriUsingTree(tree, docId);
            Cursor c = ctx.getContentResolver().query(
                    doc,
                    new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},
                    null, null, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) {
                        String n = c.getString(0);
                        if (n != null && n.length() > 0) {
                            return n;
                        }
                    }
                } finally {
                    c.close();
                }
            }
            return docId;
        } catch (Exception e) {
            return tree.toString();
        }
    }

    static boolean hasPermission(Context ctx, Uri tree) {
        List<UriPermission> perms = ctx.getContentResolver().getPersistedUriPermissions();
        for (UriPermission p : perms) {
            if (p.getUri().equals(tree) && p.isWritePermission()) {
                return true;
            }
        }
        return false;
    }

    static void release(Context ctx, Uri tree) {
        try {
            ctx.getContentResolver().releasePersistableUriPermission(
                    tree,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception e) {
            // ja nao tinha a permissao
        }
    }

    /** Id do arquivo com esse nome dentro da pasta; null se nao existir. */
    private static String findChildId(Context ctx, Uri tree, String name) {
        String parentId = DocumentsContract.getTreeDocumentId(tree);
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
        Cursor c = ctx.getContentResolver().query(
                children,
                new String[]{
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME},
                null, null, null);
        if (c == null) {
            return null;
        }
        try {
            while (c.moveToNext()) {
                if (name.equals(c.getString(1))) {
                    return c.getString(0);
                }
            }
        } finally {
            c.close();
        }
        return null;
    }

    private static void writeBytes(ContentResolver cr, Uri uri, String mode, byte[] data)
            throws Exception {
        OutputStream os = cr.openOutputStream(uri, mode);
        if (os == null) {
            throw new Exception("Não consegui abrir o arquivo para gravar.");
        }
        try {
            os.write(data);
            os.flush();
        } finally {
            os.close();
        }
    }

    static void write(Context ctx, Uri tree, String name, String text) throws Exception {
        if (!hasPermission(ctx, tree)) {
            throw new Exception("O Android não guardou a permissão desta pasta. Escolha a pasta de novo.");
        }
        ContentResolver cr = ctx.getContentResolver();
        byte[] data = text.getBytes("UTF-8");

        String childId = findChildId(ctx, tree, name);
        if (childId != null) {
            Uri doc = DocumentsContract.buildDocumentUriUsingTree(tree, childId);
            try {
                writeBytes(cr, doc, "wt", data);
                return;
            } catch (Exception first) {
                // alguns provedores nao aceitam o modo "wt": apaga e recria
                try {
                    DocumentsContract.deleteDocument(cr, doc);
                } catch (Exception ignore) {
                    // segue e tenta criar
                }
            }
        }

        String parentId = DocumentsContract.getTreeDocumentId(tree);
        Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, parentId);
        Uri created = DocumentsContract.createDocument(cr, parent, "application/json", name);
        if (created == null) {
            throw new Exception("Não consegui criar o arquivo nesta pasta.");
        }
        writeBytes(cr, created, "w", data);
    }

    /** Conteudo do arquivo, ou null se ele nao existe na pasta. */
    static String read(Context ctx, Uri tree, String name) throws Exception {
        if (!hasPermission(ctx, tree)) {
            throw new Exception("O Android não guardou a permissão desta pasta. Escolha a pasta de novo.");
        }
        String childId = findChildId(ctx, tree, name);
        if (childId == null) {
            return null;
        }
        Uri doc = DocumentsContract.buildDocumentUriUsingTree(tree, childId);
        InputStream in = ctx.getContentResolver().openInputStream(doc);
        if (in == null) {
            throw new Exception("Não consegui abrir o arquivo para ler.");
        }
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return new String(out.toByteArray(), "UTF-8");
        } finally {
            in.close();
        }
    }
}
