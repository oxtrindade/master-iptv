package com.rodrigo.master_notas;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ChecklistWidgetService extends RemoteViewsService {

    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        int id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID);
        return new Factory(getApplicationContext(), id);
    }

    private static class Factory implements RemoteViewsFactory {
        private final Context context;
        private final int widgetId;
        private String noteId;
        private final List<String[]> items = new ArrayList<String[]>();

        Factory(Context context, int widgetId) {
            this.context = context;
            this.widgetId = widgetId;
        }

        @Override
        public void onCreate() {
        }

        @Override
        public void onDataSetChanged() {
            items.clear();
            noteId = ChecklistData.widgetNoteId(context, widgetId);
            JSONObject note = ChecklistData.findNote(ChecklistData.read(context), noteId);
            if (note == null || ChecklistData.isTrashed(note)) {
                return;
            }
            JSONArray blocks = note.optJSONArray("blocks");
            if (blocks == null) {
                return;
            }
            for (int i = 0; i < blocks.length(); i++) {
                JSONObject b = blocks.optJSONObject(i);
                if (b == null) {
                    continue;
                }
                String type = b.optString("t");
                String text = b.optString("x", "").trim();
                if ("check".equals(type)) {
                    if (text.length() == 0) {
                        continue;
                    }
                    items.add(new String[]{
                            b.optString("id"),
                            text,
                            b.optBoolean("k", false) ? "1" : "0",
                            "c"
                    });
                } else if ("draw".equals(type)) {
                    items.add(new String[]{"", "[desenho]", "0", "d"});
                } else if (text.length() > 0) {
                    items.add(new String[]{"", text, "0", "t"});
                }
            }
        }

        @Override
        public void onDestroy() {
            items.clear();
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public RemoteViews getViewAt(int position) {
            if (position < 0 || position >= items.size()) {
                return null;
            }
            String[] it = items.get(position);
            boolean done = "1".equals(it[2]);
            boolean isCheck = "c".equals(it[3]);

            RemoteViews row = new RemoteViews(context.getPackageName(), R.layout.widget_check_item);
            row.setTextViewText(R.id.item_text,
                    isCheck ? (done ? "☑  " : "☐  ") + it[1] : it[1]);
            row.setTextColor(R.id.item_text,
                    context.getColor(done ? R.color.widget_text_done : R.color.widget_text));

            Intent fill = new Intent();
            if (isCheck) {
                fill.putExtra(ChecklistWidgetProvider.EXTRA_NOTE_ID, noteId);
                fill.putExtra(ChecklistWidgetProvider.EXTRA_BLOCK_ID, it[0]);
            }
            row.setOnClickFillInIntent(R.id.item_root, fill);
            return row;
        }

        @Override
        public RemoteViews getLoadingView() {
            return null;
        }

        @Override
        public int getViewTypeCount() {
            return 1;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public boolean hasStableIds() {
            return false;
        }
    }
}
