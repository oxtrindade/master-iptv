package com.rodrigo.master_notas;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

import org.json.JSONObject;

public class ChecklistWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_TOGGLE = "com.rodrigo.master_notas.WIDGET_TOGGLE";
    public static final String EXTRA_NOTE_ID = "extra_note_id";
    public static final String EXTRA_BLOCK_ID = "extra_block_id";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) {
            update(context, manager, id);
        }
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        for (int id : appWidgetIds) {
            ChecklistData.clearWidget(context, id);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && ACTION_TOGGLE.equals(intent.getAction())) {
            String noteId = intent.getStringExtra(EXTRA_NOTE_ID);
            String blockId = intent.getStringExtra(EXTRA_BLOCK_ID);
            if (noteId != null && blockId != null) {
                ChecklistData.toggle(context, noteId, blockId);
            }
            refreshAll(context);
            return;
        }
        super.onReceive(context, intent);
    }

    /** Redesenha todos os widgets de lista que estiverem na tela inicial. */
    public static void refreshAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, ChecklistWidgetProvider.class));
        for (int id : ids) {
            update(context, manager, id);
        }
    }

    static void update(Context context, AppWidgetManager manager, int widgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_checklist);

        String noteId = ChecklistData.widgetNoteId(context, widgetId);
        JSONObject note = ChecklistData.findNote(ChecklistData.read(context), noteId);
        boolean gone = note == null || ChecklistData.isTrashed(note);

        String title = "Nota";
        if (gone) {
            title = "Nota não encontrada";
        } else {
            String t = note.optString("title", "").trim();
            if (t.length() > 0) {
                title = t;
            }
        }
        views.setTextViewText(R.id.widget_title, title);
        views.setTextViewText(R.id.widget_empty,
                gone ? "A nota foi apagada ou não existe mais. Remova este widget e adicione de novo."
                        : "Nota vazia");

        Intent service = new Intent(context, ChecklistWidgetService.class);
        service.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        service.setData(Uri.parse(service.toUri(Intent.URI_INTENT_SCHEME)));
        views.setRemoteAdapter(R.id.widget_list, service);
        views.setEmptyView(R.id.widget_list, R.id.widget_empty);

        Intent toggle = new Intent(context, ChecklistWidgetProvider.class);
        toggle.setAction(ACTION_TOGGLE);
        PendingIntent togglePi = PendingIntent.getBroadcast(
                context, widgetId, toggle,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
        views.setPendingIntentTemplate(R.id.widget_list, togglePi);

        Intent launch = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (launch != null) {
            PendingIntent openPi = PendingIntent.getActivity(
                    context, widgetId, launch,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            views.setOnClickPendingIntent(R.id.widget_title, openPi);
            views.setOnClickPendingIntent(R.id.widget_empty, openPi);
        }

        manager.updateAppWidget(widgetId, views);
        manager.notifyAppWidgetViewDataChanged(widgetId, R.id.widget_list);
    }
}
