/* TMDB (themoviedb.org): "em alta" e "parecidos" de verdade, cruzados com o catálogo do provedor. ES5.
   Tmdb.init(http) recebe a função de rede do app. Precisa de uma chave de API v3 (gratuita), guardada nas Configurações. */
var Tmdb = (function () {
  'use strict';
  var http = null;
  var API = 'https://api.themoviedb.org/3';

  function getJson(path, key, params) {
    if (!http) { return Promise.reject(new Error('sem rede')); }
    var url = API + path + '?api_key=' + encodeURIComponent(key) + '&language=pt-BR' + (params || '');
    return Promise.resolve(http(url)).then(function (t) { return typeof t === 'string' ? JSON.parse(t) : t; });
  }

  /* nome comparável: sem acento, sem [tags], (ano), qualidade/idioma, pontuação */
  function norm(s) {
    var t = String(s || '').toLowerCase();
    try { t = t.normalize('NFD').replace(/[̀-ͯ]/g, ''); } catch (e) {}
    t = t.replace(/\[[^\]]*\]|\([^)]*\)/g, ' ')
      .replace(/\b(4k|uhd|fhd|hd|sd|h\.?265|hevc|legendado|dublado|dual|leg|dub|nacional|cam|web-?dl|bluray|1080p|720p)\b/g, ' ')
      .replace(/^\s*[a-z]{2,4}\s*\|\s*/, ' ')
      .replace(/[^a-z0-9]+/g, ' ').replace(/^ +| +$/g, '');
    t = t.replace(/ (l|d)$/, '');   // sufixo solto de idioma: "Filme L" (legendado) / "Filme D" (dublado)
    return t;
  }

  function plain(s) {
    var t = String(s || '').toLowerCase();
    try { t = t.normalize('NFD').replace(/[̀-ͯ]/g, ''); } catch (e) {}
    return t;
  }

  /* outra fonte de trailers: busca no YouTube ("<filme> <ano> trailer dublado") e escolhe o 1º resultado que é trailer,
     diz "dublado" (se dub) e traz as palavras do nome do filme (evita outro filme). Devolve a chave do vídeo ou ''. */
  function ytSearch(title, year, dub) {
    if (!http) { return Promise.resolve(''); }
    var t = norm(title);
    if (!t) { return Promise.resolve(''); }
    var words = t.split(' ').filter(function (w) { return w.length >= 3; }).slice(0, 5);
    var url = 'https://www.youtube.com/results?hl=pt-BR&gl=BR&sp=EgIQAQ%253D%253D&search_query=' + encodeURIComponent(t + (year ? ' ' + year : '') + ' trailer' + (dub ? ' dublado' : ''));
    return Promise.resolve(http(url)).then(function (html) {
      html = String(html || '');
      if (html.indexOf('\\x22') >= 0) { html = html.replace(/\\x([0-9a-fA-F]{2})/g, function (m, x) { return String.fromCharCode(parseInt(x, 16)); }); }
      var re = /"videoRenderer":\{"videoId":"([\w-]{11})"[\s\S]{0,2500}?"title":\{"runs":\[\{"text":"((?:[^"\\]|\\.)*)"/g, m;
      while ((m = re.exec(html))) {
        var tt = plain(m[2]);
        if (!/trailer|teaser/.test(tt) || (dub && !/dublad/.test(tt))) { continue; }
        var all = true, i;
        for (i = 0; i < words.length; i++) { if (tt.indexOf(words[i]) < 0) { all = false; break; } }
        if (all) { return m[1]; }
      }
      return '';
    }).then(null, function () { return ''; });
  }

  function yearOf(name) {
    var m = String(name || '').match(/\((\d{4})\)|\b(19\d{2}|20\d{2})\b/);
    return m ? parseInt(m[1] || m[2], 10) : 0;
  }

  function buildIndex(list) {
    if (list._tmdbIdx) { return list._tmdbIdx; }
    var idx = {}, i, it, k;
    for (i = 0; i < list.length; i++) {
      it = list[i];
      k = norm(it.name);
      if (!k) { continue; }
      (idx[k] = idx[k] || []).push(it);
    }
    try { Object.defineProperty(list, '_tmdbIdx', { value: idx, enumerable: false, configurable: true }); } catch (e) { list._tmdbIdx = idx; }
    return idx;
  }

  /* versão do título no catálogo: idioma (dublado/legendado/padrão) e qualidade */
  var RE_LEG = /(^|[^a-z0-9])(legendado|leg)([^a-z0-9]|$)|[\[(]\s*l\s*[\])]|[\s\-|]l\s*$/i;
  var RE_DUB = /(^|[^a-z0-9])(dublado|dub|dual)([^a-z0-9]|$)|[\[(]\s*d\s*[\])]|[\s\-|]d\s*$/i;
  function variantInfo(name) {
    var n = String(name || ''), lang = RE_LEG.test(n) ? 'leg' : (RE_DUB.test(n) ? 'dub' : 'orig'), q = '';
    if (/(^|[^a-z0-9])(4k|uhd|2160p)([^a-z0-9]|$)/i.test(n)) { q = '4K'; }
    else if (/(^|[^a-z0-9])(fhd|1080p)([^a-z0-9]|$)/i.test(n)) { q = 'Full HD'; }
    else if (/(^|[^a-z0-9])(hd|720p)([^a-z0-9]|$)/i.test(n)) { q = 'HD'; }
    else if (/(^|[^a-z0-9])sd([^a-z0-9]|$)/i.test(n)) { q = 'SD'; }
    var base = lang === 'leg' ? 'Legendado' : (lang === 'dub' ? 'Dublado' : 'Padrão');
    return { lang: lang, q: q, label: base + (q ? ' · ' + q : '') };
  }

  var pref = 'dub';   // 'dub' | 'leg' | 'any'
  var tv4k = false;   // TV (webOS / Android TV): entre versões do mesmo idioma, prefere 4K
  function rank(it) {
    var v = variantInfo(it.name), r = 0;
    if (pref === 'dub') { r = v.lang === 'dub' ? 6 : (v.lang === 'orig' ? 4 : 0); }
    else if (pref === 'leg') { r = v.lang === 'leg' ? 6 : (v.lang === 'orig' ? 2 : 0); }
    return r + (v.q === '4K' ? (tv4k ? 0.9 : 0.4) : (v.q === 'Full HD' ? 0.5 : (v.q === 'HD' ? 0.3 : 0)));
  }

  /* todas as versões do mesmo título no catálogo (mesmo tipo, ano compatível), a preferida primeiro */
  function variants(list, item) {
    var idx = buildIndex(list), arr = idx[norm(item.name)] || [], year = yearOf(item.name) || parseInt(item.year, 10) || 0, out = [], i, c, cy;
    for (i = 0; i < arr.length; i++) {
      c = arr[i];
      if (c.type !== item.type || String(c.id) === String(item.id)) { continue; }
      cy = yearOf(c.name) || parseInt(c.year, 10) || 0;
      if (year && cy && Math.abs(cy - year) > 1) { continue; }
      out.push(c);
    }
    out.push(item);
    out.sort(function (a, b) { return rank(b) - rank(a); });
    return out;
  }

  function pick(cands, year) {
    var best = null, i, c, cy, score, bs = -1;
    for (i = 0; i < cands.length; i++) {
      c = cands[i]; cy = c.year ? parseInt(String(c.year).slice(0, 4), 10) : yearOf(c.name);
      if (year && cy && Math.abs(cy - year) > 1) { continue; }
      score = (c.rating || 0) * 0.1 + (c.logo ? 1 : 0) + (year && cy === year ? 2 : 0) + rank(c) * 2;
      if (score > bs) { bs = score; best = c; }
    }
    return best;
  }

  /* results: [{t, o, y}] (título, título original, ano) na ordem do ranking -> itens do catálogo, sem repetir */
  function match(list, results) {
    var idx = buildIndex(list), out = [], seen = {}, i, r, c, k;
    for (i = 0; i < results.length; i++) {
      r = results[i];
      c = null;
      [r.t, r.o].forEach(function (name) {
        if (!c && name) { var arr = idx[norm(name)]; if (arr) { c = pick(arr, r.y); } }
      });
      if (c) {
        k = c.type + ':' + c.id;
        if (!seen[k]) { seen[k] = 1; out.push(c); }
      }
    }
    return out;
  }

  function slim(kind, r) {
    var d = kind === 'tv' ? r.first_air_date : r.release_date;
    return { id: r.id, t: kind === 'tv' ? r.name : r.title, o: kind === 'tv' ? r.original_name : r.original_title, y: d ? parseInt(String(d).slice(0, 4), 10) : 0 };
  }

  function list(kind, path, key, pages) {
    var ps = [], p;
    for (p = 1; p <= pages; p++) { ps.push(getJson(path, key, '&page=' + p)); }
    return Promise.all(ps).then(function (rs) {
      var out = [];
      rs.forEach(function (r) { (r.results || []).forEach(function (x) { out.push(slim(kind, x)); }); });
      return out;
    });
  }

  return {
    init: function (h) { http = h; },
    norm: norm,
    variantInfo: variantInfo,
    variants: variants,
    rank: rank,
    setTv4k: function (on) { tv4k = !!on; },
    best: function (items) {
      // uma versão por título (a de maior preferência), mantendo a ordem de chegada
      var by = {}, order = [], i, k, it;
      for (i = 0; i < items.length; i++) {
        it = items[i]; k = it.type + ':' + norm(it.name) + ':' + (yearOf(it.name) || parseInt(it.year, 10) || 0);
        if (!by[k]) { by[k] = it; order.push(k); }
        else if (rank(it) > rank(by[k])) { by[k] = it; }
      }
      return order.map(function (x) { return by[x]; });
    },
    setPref: function (p) { pref = p === 'leg' || p === 'any' ? p : 'dub'; },
    yearOf: yearOf,
    ytSearch: ytSearch,
    match: match,
    trending: function (kind, key) { return list(kind, '/trending/' + kind + '/week', key, 2); },
    recommend: function (kind, id, key) { return list(kind, '/' + kind + '/' + id + '/recommendations', key, 1); },
    findId: function (kind, title, year, key) {
      var extra = '&query=' + encodeURIComponent(norm(title)) + (year ? (kind === 'tv' ? '&first_air_date_year=' : '&year=') + year : '');
      return getJson('/search/' + kind, key, extra).then(function (r) {
        var x = r.results && r.results[0];
        return x ? x.id : 0;
      });
    },
    /* trailer no YouTube: devolve a chave do vídeo ('' se não houver). dub=true: só trailer em português do Brasil
       cujo nome diz "dublado" (o idioma "pt" do TMDB também marca trailers só legendados) */
    trailer: function (kind, id, key, dub) {
      return getJson('/' + kind + '/' + id + '/videos', key, '&include_video_language=pt%2Cen%2Cnull').then(function (r) {
        var l = (r.results || []).filter(function (v) { return v.site === 'YouTube' && (v.type === 'Trailer' || v.type === 'Teaser'); });
        if (dub) { l = l.filter(function (v) { return v.iso_639_1 === 'pt' && v.iso_3166_1 !== 'PT' && /dublad/.test(plain(v.name)); }); }
        l.sort(function (a, b) {
          function sc(v) { return (v.type === 'Trailer' ? 8 : 0) + (v.iso_3166_1 === 'BR' ? 4 : 0) + (v.official ? 2 : 0) + (v.iso_639_1 === 'pt' ? 1 : 0); }
          return sc(b) - sc(a);
        });
        return l[0] ? l[0].key : '';
      });
    },
    /* elenco principal: [{id, n (nome), c (personagem), p (foto)}] */
    credits: function (kind, id, key) {
      return getJson('/' + kind + '/' + id + '/credits', key, '').then(function (r) {
        return (r.cast || []).slice(0, 15).map(function (c) { return { id: c.id, n: c.name || '', c: c.character || '', p: c.profile_path || '' }; });
      });
    },
    /* filmografia de uma pessoa (mais populares primeiro): [{t, o, y, k:'movie'|'tv'}] */
    person: function (id, key) {
      return getJson('/person/' + id + '/combined_credits', key, '').then(function (r) {
        var c = (r.cast || []).filter(function (x) { return x.media_type === 'movie' || x.media_type === 'tv'; });
        c.sort(function (a, b) { return (b.popularity || 0) - (a.popularity || 0); });
        return c.slice(0, 80).map(function (x) { var o = slim(x.media_type, x); o.k = x.media_type; return o; });
      });
    },
    check: function (key) { return getJson('/configuration', key, ''); }
  };
})();
if (typeof module !== 'undefined' && module.exports) { module.exports = Tmdb; }
