/* Esportes: placares e jogos do dia (futebol) + ligação do jogo com o canal que o transmite. ES5.
   Fonte: API pública de placares da ESPN (sem chave, não oficial: pode mudar ou sair do ar; o app trata a falha).
   Sports.fetch(http, ...) usa a função de rede do app (XHR com fallback pelo proxy local). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) { module.exports = factory(); }
  else { root.Sports = factory(); }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var Sp = {};

  Sp.BASE = 'https://site.api.espn.com/apis/site/v2/sports/soccer';
  Sp.setBase = function (b) { Sp.BASE = b; };

  /* all: mostra todos os jogos; friendly: só jogos do Brasil ou de times que você segue */
  Sp.LEAGUES = [
    { id: 'bra.1', name: 'Brasileirão Série A', short: 'Brasileirão', all: true },
    { id: 'bra.copa_do_brazil', name: 'Copa do Brasil', short: 'Copa do Brasil', all: true },
    { id: 'conmebol.libertadores', name: 'Copa Libertadores', short: 'Libertadores', all: true },
    { id: 'conmebol.sudamericana', name: 'Copa Sul-Americana', short: 'Sul-Americana', all: true },
    { id: 'uefa.champions', name: 'UEFA Champions League', short: 'Champions', all: true },
    { id: 'eng.1', name: 'Premier League', short: 'Premier League', all: true },
    { id: 'esp.1', name: 'La Liga', short: 'La Liga', all: true },
    { id: 'fra.1', name: 'Ligue 1', short: 'Ligue 1', all: true },
    { id: 'ita.1', name: 'Campeonato Italiano (Serie A)', short: 'Serie A', all: true },
    { id: 'ger.1', name: 'Bundesliga', short: 'Bundesliga', all: true },
    { id: 'fifa.friendly', name: 'Amistosos de seleções', short: 'Amistosos', all: false, nat: true },
    { id: 'fifa.worldq.conmebol', name: 'Eliminatórias Sul-Americanas', short: 'Eliminatórias', all: true, nat: true },
    { id: 'conmebol.america', name: 'Copa América', short: 'Copa América', all: true, nat: true },
    { id: 'uefa.euro', name: 'Eurocopa', short: 'Eurocopa', all: true, nat: true },
    { id: 'uefa.nations', name: 'UEFA Nations League', short: 'Nations League', all: true, nat: true },
    { id: 'fifa.world', name: 'Copa do Mundo', short: 'Copa do Mundo', all: true, nat: true }
  ];

  Sp.league = function (id) {
    var i;
    for (i = 0; i < Sp.LEAGUES.length; i++) { if (Sp.LEAGUES[i].id === id) { return Sp.LEAGUES[i]; } }
    return null;
  };

  /* ---------- texto ---------- */

  Sp.norm = function (s) {
    s = String(s == null ? '' : s).toLowerCase();
    try { s = s.normalize('NFD').replace(/[̀-ͯ]/g, ''); } catch (e) { /* sem normalize */ }
    return s.replace(/[^a-z0-9]+/g, ' ').replace(/^ +| +$/g, '');
  };

  // nomes de seleções em inglês (como a fonte envia) -> como aparecem na programação em português
  var PT = {
    'brazil': 'brasil', 'germany': 'alemanha', 'france': 'franca', 'spain': 'espanha', 'england': 'inglaterra',
    'italy': 'italia', 'netherlands': 'holanda', 'belgium': 'belgica', 'uruguay': 'uruguai', 'paraguay': 'paraguai',
    'ecuador': 'equador', 'mexico': 'mexico', 'united states': 'estados unidos', 'usa': 'estados unidos', 'japan': 'japao',
    'croatia': 'croacia', 'switzerland': 'suica', 'denmark': 'dinamarca', 'sweden': 'suecia', 'norway': 'noruega',
    'poland': 'polonia', 'czechia': 'tchequia', 'czech republic': 'tchequia', 'scotland': 'escocia', 'wales': 'pais de gales',
    'turkey': 'turquia', 'turkiye': 'turquia', 'serbia': 'servia', 'greece': 'grecia', 'austria': 'austria', 'ukraine': 'ucrania',
    'south korea': 'coreia do sul', 'morocco': 'marrocos', 'egypt': 'egito', 'senegal': 'senegal', 'cameroon': 'camaroes',
    'saudi arabia': 'arabia saudita', 'australia': 'australia', 'canada': 'canada', 'costa rica': 'costa rica',
    'hungary': 'hungria', 'romania': 'romenia', 'slovakia': 'eslovaquia', 'slovenia': 'eslovenia', 'albania': 'albania',
    'georgia': 'georgia', 'ireland': 'irlanda', 'northern ireland': 'irlanda do norte', 'iceland': 'islandia', 'finland': 'finlandia',
    'new zealand': 'nova zelandia', 'south africa': 'africa do sul', 'ivory coast': 'costa do marfim', 'algeria': 'argelia',
    'tunisia': 'tunisia', 'nigeria': 'nigeria', 'ghana': 'gana', 'iran': 'ira', 'qatar': 'catar', 'panama': 'panama', 'jamaica': 'jamaica'
  };
  // nomes de clubes que viram só uma palavra e podem confundir (não usar a 1ª palavra sozinha)
  var AMBIG = { atletico: 1, athletico: 1, sport: 1, real: 1, united: 1, city: 1, club: 1, deportivo: 1, independiente: 1, nacional: 1, universidad: 1, sporting: 1, olimpia: 1 };

  /* termos (normalizados) que identificam um time numa programação de TV */
  Sp.teamTerms = function (t) {
    var out = [], seen = {};
    function add(s) {
      s = Sp.norm(s);
      if (s.length >= 3 && !seen[s]) { seen[s] = 1; out.push(s); }
    }
    [t.name, t.short].forEach(function (n) {
      if (!n) { return; }
      var k = Sp.norm(n);
      add(n);
      if (PT[k]) { add(PT[k]); }
      add(String(n).replace(/\b(FC|SC|EC|CF|AC|CD|AFC|SE|FBC|RB|Clube|Club|de|da|do|Futebol|Regatas)\b/gi, ' '));
    });
    var first = Sp.norm(t.name || '').split(' ')[0];
    if (first && first.length >= 6 && !AMBIG[first] && !seen[first]) { out.push(first); }
    return out;
  };

  function hasTerm(text, terms) {
    var i, tx = ' ' + text + ' ';
    for (i = 0; i < terms.length; i++) { if (tx.indexOf(' ' + terms[i] + ' ') >= 0) { return true; } }
    return false;
  }

  /* 2 = os dois times aparecem no texto; 1 = um time e jeito de confronto ("x", "vs"); 0 = não */
  Sp.matchText = function (game, text) {
    var tx = Sp.norm(text);
    if (!tx) { return 0; }
    var a = hasTerm(tx, Sp.teamTerms(game.home)), b = hasTerm(tx, Sp.teamTerms(game.away));
    if (a && b) { return 2; }
    if ((a || b) && / (x|vs|v|versus|contra) /.test(' ' + tx + ' ')) { return 1; }
    return 0;
  };

  /* ---------- jogos ---------- */

  function stat(c, key) {
    var list = (c && c.statistics) || [], i;
    for (i = 0; i < list.length; i++) { if (list[i].name === key || list[i].abbreviation === key) { return list[i].displayValue; } }
    return '';
  }

  function team(c) {
    var t = (c && c.team) || {};
    return {
      id: String(t.id || ''), name: Sp.ptName(t.displayName || t.name || ''), short: Sp.ptName(t.shortDisplayName || ''), abbr: t.abbreviation || '',
      logo: t.logo || (t.logos && t.logos[0] && t.logos[0].href) || '', color: /^[0-9a-fA-F]{6}$/.test(t.color || '') ? t.color : '',
      score: c && c.score != null && c.score !== '' ? String(typeof c.score === 'object' ? (c.score.displayValue || c.score.value) : c.score) : '',
      winner: !!(c && c.winner),
      stats: { poss: stat(c, 'possessionPct'), shots: stat(c, 'totalShots'), sot: stat(c, 'shotsOnTarget'), fouls: stat(c, 'foulsCommitted'), corners: stat(c, 'wonCorners'), yellow: stat(c, 'yellowCards'), red: stat(c, 'redCards') }
    };
  }

  Sp.parseEvent = function (ev, leagueId) {
    var comp = (ev.competitions && ev.competitions[0]) || {}, cs = comp.competitors || [], home = null, away = null, i;
    for (i = 0; i < cs.length; i++) {
      if (cs[i].homeAway === 'home') { home = cs[i]; } else if (cs[i].homeAway === 'away') { away = cs[i]; }
    }
    if (!home || !away) { home = cs[0]; away = cs[1]; }
    if (!home || !away) { return null; }
    var st = ev.status || {}, ty = st.type || {}, state = ty.state === 'in' ? 'in' : (ty.state === 'post' ? 'post' : 'pre');
    var lg = Sp.league(leagueId), when = Date.parse(ev.date);
    if (!isFinite(when)) { return null; }
    var goals = [];
    (comp.details || []).forEach(function (d) {
      if (d.scoringPlay) {
        var p = d.athletesInvolved && d.athletesInvolved[0];
        goals.push({ min: (d.clock && d.clock.displayValue) || '', who: p ? (p.displayName || p.fullName || '') : '', own: !!d.ownGoal, pen: !!d.penaltyKick, home: String(d.team && d.team.id) === String(home.team && home.team.id) });
      }
    });
    return {
      id: String(ev.id), league: leagueId, leagueName: lg ? lg.short : leagueId, nat: !!(lg && lg.nat),
      start: when, state: state, clock: st.displayClock || '', detail: ty.shortDetail || ty.detail || '', typeName: ty.name || '',
      period: st.period || 0, completed: !!ty.completed,
      home: team(home), away: team(away), venue: (comp.venue && comp.venue.fullName) || '', goals: goals,
      note: (comp.notes && comp.notes[0] && comp.notes[0].headline) || ''
    };
  };

  function ymd(d) {
    var m = d.getMonth() + 1, day = d.getDate();
    return d.getFullYear() + (m < 10 ? '0' : '') + m + (day < 10 ? '0' : '') + day;
  }
  Sp.ymd = ymd;

  function getJson(http, url) {
    return Promise.resolve(http(url)).then(function (t) { return typeof t === 'string' ? JSON.parse(t) : t; });
  }

  /* Jogos de UM dia (a fonte não aceita intervalo de datas). date: Date; leagues: ids (padrão: todas).
     Uma consulta por liga; a que falhar não derruba as outras. Resolve { games: [...ordenados por horário], failed: [ids] } */
  Sp.fetchDay = function (http, date, leagues) {
    var ids = leagues || Sp.LEAGUES.map(function (l) { return l.id; }), failed = [];
    return Promise.all(ids.map(function (id) {
      return getJson(http, Sp.BASE + '/' + id + '/scoreboard?limit=200&dates=' + ymd(date)).then(function (d) {
        var out = [];
        ((d && d.events) || []).forEach(function (ev) { var g = Sp.parseEvent(ev, id); if (g) { out.push(g); } });
        return out;
      }, function () { failed.push(id); return []; });
    })).then(function (lists) {
      var games = [], seen = {};
      lists.forEach(function (l) { l.forEach(function (g) { if (!seen[g.league + g.id]) { seen[g.league + g.id] = 1; games.push(g); } }); });
      games.sort(function (a, b) { return a.start - b.start; });
      return { games: games, failed: failed };
    });
  };

  /* times de uma liga/competição: [{id, name, logo}] ordenados por nome (seleções incluídas: fifa.world) */
  Sp.parseTeams = function (d) {
    var out = [], seen = {};
    var lg = d && d.sports && d.sports[0] && d.sports[0].leagues && d.sports[0].leagues[0];
    ((lg && lg.teams) || []).forEach(function (x) {
      var t = x && x.team;
      if (!t || !t.id || seen[t.id]) { return; }
      seen[t.id] = 1;
      out.push({ id: String(t.id), name: Sp.ptName(t.displayName || t.name || t.shortDisplayName || ''), logo: (t.logos && t.logos[0] && t.logos[0].href) || '' });
    });
    out.sort(function (a, b) { return a.name < b.name ? -1 : a.name > b.name ? 1 : 0; });
    return out;
  };
  Sp.fetchTeams = function (http, leagueId) {
    return getJson(http, Sp.BASE + '/' + leagueId + '/teams?limit=200').then(Sp.parseTeams);
  };


  /* classificação (tabela) de uma liga: [{name, rows:[{pos,id,name,logo,gp,w,d,l,gd,pts}]}] — uma tabela por grupo/fase */
  function sv(stats, names) {
    var i, j;
    for (j = 0; j < names.length; j++) {
      for (i = 0; i < (stats || []).length; i++) { if (stats[i].name === names[j] || stats[i].abbreviation === names[j]) { return stats[i].value != null ? stats[i].value : parseFloat(stats[i].displayValue); } }
    }
    return null;
  }
  Sp.parseStandings = function (d) {
    var out = [];
    function table(node, label) {
      var es = node && node.standings && node.standings.entries;
      if (!es || !es.length) { return; }
      var rows = es.map(function (e, i) {
        var t = e.team || {}, st = e.stats || [], r = sv(st, ['rank']);
        return { pos: r != null && isFinite(r) ? Math.round(r) : i + 1, id: String(t.id || ''), name: Sp.ptName(t.displayName || t.name || ''),
          logo: (t.logos && t.logos[0] && t.logos[0].href) || t.logo || '',
          gp: sv(st, ['gamesPlayed', 'GP']), w: sv(st, ['wins', 'W']), d: sv(st, ['ties', 'draws', 'D']), l: sv(st, ['losses', 'L']),
          gd: sv(st, ['pointDifferential', 'goalDifference', 'GD']), pts: sv(st, ['points', 'PTS']) };
      });
      rows.sort(function (a, b) { return a.pos - b.pos; });
      out.push({ name: label || '', rows: rows });
    }
    if (d && d.children && d.children.length) {
      d.children.forEach(function (c) { table(c, d.children.length > 1 ? (c.name || c.abbreviation || '') : ''); });
    } else { table(d, ''); }
    return out;
  };
  Sp.fetchStandings = function (http, leagueId) {
    return getJson(http, Sp.BASE.replace('/site/v2/', '/v2/') + '/' + leagueId + '/standings').then(Sp.parseStandings);
  };


  /* escalações (ESPN summary): [{ home: bool, formation: '4-3-3', players: [{ name, num, pos, place, x, y }] }]. x = 0..100 no sentido do ataque, y = 0..100 de lado a lado */
  Sp.parseLineups = function (d) {
    var out = [];
    ((d && d.rosters) || []).forEach(function (r) {
      var starters = ((r.roster) || []).filter(function (p) { return p.starter; });
      if (starters.length < 7) { return; }
      starters.forEach(function (p, i) { p._i = i; });
      starters.sort(function (a, b) { return (parseInt(a.formationPlace, 10) || 99) - (parseInt(b.formationPlace, 10) || 99) || a._i - b._i; });
      var fm = String(r.formation || r.formationName || ''), lines = fm.split('-').map(function (n) { return parseInt(n, 10); }).filter(function (n) { return n > 0; });
      var total = lines.reduce(function (a, b) { return a + b; }, 0);
      if (total !== starters.length - 1) { lines = [starters.length - 1 > 4 ? 4 : starters.length - 1]; lines.push(starters.length - 1 - lines[0]); fm = ''; }
      var layout = [1].concat(lines), idx = 0, players = [];
      layout.forEach(function (n, li) {
        var x = 6 + li * (40 / Math.max(1, layout.length - 1));
        for (var j = 0; j < n; j++) {
          var p = starters[idx++]; if (!p) { return; }
          var a = p.athlete || {};
          players.push({ name: a.shortName || a.displayName || a.fullName || '', num: String(p.jersey || a.jersey || ''), pos: (p.position && p.position.abbreviation) || '', x: x, y: (j + 1) / (n + 1) * 100 });
        }
      });
      out.push({ home: r.homeAway !== 'away', formation: fm, team: (r.team && (r.team.displayName || r.team.name)) || '', players: players });
    });
    return out;
  };
  Sp.fetchLineup = function (http, leagueId, eventId) {
    return getJson(http, Sp.BASE + '/' + leagueId + '/summary?event=' + encodeURIComponent(eventId)).then(Sp.parseLineups);
  };

  /* amistosos: só os do Brasil (ou de times que você segue) para não encher a tela */
  Sp.visible = function (g, follow) {
    var lg = Sp.league(g.league);
    if (!lg || lg.all) { return true; }
    follow = follow || {};
    return g.home.abbr === 'BRA' || g.away.abbr === 'BRA' || !!follow[g.home.id] || !!follow[g.away.id];
  };

  Sp.dayKey = function (ms) { return ymd(new Date(ms)); };

  Sp.isLive = function (g) { return g.state === 'in'; };

  function hhmm(ms) {
    var d = new Date(ms), h = d.getHours(), m = d.getMinutes();
    return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
  }
  Sp.hhmm = hhmm;

  /* texto curto do estado: "AO VIVO 67'", "Intervalo", "Encerrado", "16:00" */
  Sp.statusText = function (g) {
    if (g.state === 'in') {
      if (/half ?time|halftime/i.test(g.typeName + ' ' + g.detail)) { return 'Intervalo'; }
      return 'AO VIVO' + (g.clock ? ' ' + g.clock : '');
    }
    if (g.state === 'post') {
      if (/postponed|adiad/i.test(g.typeName + g.detail)) { return 'Adiado'; }
      if (/cancel/i.test(g.typeName + g.detail)) { return 'Cancelado'; }
      return 'Encerrado';
    }
    if (/postponed/i.test(g.typeName + g.detail)) { return 'Adiado'; }
    return hhmm(g.start);
  };

  /* ---------- onde assistir (direitos no Brasil; serviços sem guia de programação, como HBO Max e YouTube) ---------- */
  /* Tabela fixa, conferida na imprensa em nov/2026. Os direitos mudam por temporada e, em alguns torneios, por jogo. */
  var RIGHTS = {
    'uefa.champions': { short: 'HBO Max · TNT · SBT', lines: ['HBO Max — todos os jogos', 'TNT e Space (TV paga) — jogos selecionados', 'TNT Sports no YouTube — jogos selecionados', 'SBT (TV aberta) — 1 jogo por semana, nas terças'] },
    'conmebol.libertadores': { short: 'ESPN · Paramount+ · Globo', lines: ['ESPN e Disney+ — 8 jogos por rodada', 'Paramount+ — 8 jogos por rodada', 'Globo (TV aberta) — 1 jogo por rodada (times como Flamengo, Fluminense, Corinthians e Palmeiras)'] },
    'conmebol.sudamericana': { short: 'ESPN · Paramount+ · SBT', lines: ['ESPN e Disney+ — 8 jogos por rodada', 'Paramount+ — 8 jogos por rodada', 'SBT (TV aberta) — 1 jogo por rodada (São Paulo e Santos)'] },
    'eng.1': { short: 'CazéTV', lines: ['CazéTV (YouTube, grátis) — 1 jogo por rodada'] },
    'esp.1': { short: 'CazéTV', lines: ['CazéTV (YouTube, grátis) — todos os jogos'] },
    'fra.1': { short: 'CazéTV · Xsports', lines: ['CazéTV (YouTube, grátis)', 'Xsports (TV aberta) — 3 jogos por rodada'] },
    'ita.1': { short: 'SportyNet', lines: ['SportyNet (YouTube, aberto)'] },
    'uefa.nations': { short: 'Premiere · ge tv', lines: ['Premiere (TV paga) — jogos selecionados', 'ge tv (YouTube, grátis) — jogos selecionados'] },
    'ger.1': { short: 'SportyNet', lines: ['SportyNet (YouTube, aberto)'] }
  };
  var LIBRA = ['atletico mg', 'atletico mineiro', 'bahia', 'gremio', 'flamengo', 'palmeiras', 'bragantino', 'remo', 'santos', 'sao paulo', 'vitoria'];
  var FFU = ['botafogo', 'chapecoense', 'corinthians', 'coritiba', 'cruzeiro', 'fluminense', 'internacional', 'mirassol', 'vasco'];
  function teamIn(list, name) {
    var n = ' ' + Sp.norm(name) + ' ';
    return list.some(function (k) { return n.indexOf(' ' + k) >= 0; });
  }
  /* devolve { short, lines } ou null quando não há informação para a competição */
  Sp.whereToWatch = function (g) {
    if (g.league === 'bra.1') {
      if (teamIn(LIBRA, g.home.name)) {
        return { short: 'Globo · SporTV · Premiere', lines: ['Globo (TV aberta), SporTV e Premiere — a Globo define onde passa cada jogo', 'ge tv (YouTube) — 1 jogo por rodada', 'Globoplay — acesso aos canais da Globo'] };
      }
      if (teamIn(FFU, g.home.name)) {
        return { short: 'Globo · Premiere · Record · CazéTV · Prime', lines: ['Globo (TV aberta), SporTV e Premiere', 'Record (TV aberta) e CazéTV (YouTube) — 1 jogo por rodada', 'Prime Video — 1 jogo exclusivo por rodada'] };
      }
      return { short: 'Globo · Premiere', lines: ['Globo (TV aberta), SporTV e Premiere'] };
    }
    return RIGHTS[g.league] || null;
  };

  /* links do YouTube para as fontes que transmitem lá (abre o app do YouTube) */
  var YT = [
    { re: /Caz[eé]TV/, label: 'CazéTV', url: 'https://www.youtube.com/@CazeTV/live', streams: 'https://www.youtube.com/@CazeTV/streams', tries: ['https://www.youtube.com/@CazeTV/live'] },
    { re: /TNT Sports/, label: 'TNT Sports', url: 'https://www.youtube.com/@TNTSportsBR/live', streams: 'https://www.youtube.com/@TNTSportsBR/streams', tries: ['https://www.youtube.com/@TNTSportsBR/live'] },
    { re: /ge tv/i, label: 'ge tv', url: 'https://www.youtube.com/@getv/live', streams: 'https://www.youtube.com/@getv/streams', tries: ['https://www.youtube.com/@getv/live'] },
    { re: /SportyNet/, label: 'SportyNet', url: 'https://www.youtube.com/channel/UCMcc9elPZGpg6eU4i3YaCpA/live', streams: 'https://www.youtube.com/channel/UCMcc9elPZGpg6eU4i3YaCpA/streams', cid: 'UCMcc9elPZGpg6eU4i3YaCpA',
      tries: ['https://www.youtube.com/channel/UCMcc9elPZGpg6eU4i3YaCpA/live'] }
  ];
  Sp.youtubeLinks = function (wr, any) {
    var txt = wr && wr.lines ? wr.lines.join('\n') : '', out = [];
    YT.forEach(function (y) { if (y.re.test(txt)) { out.push({ label: y.label, url: y.url, tries: y.tries, streams: y.streams, cid: y.cid }); } });
    /* direitos mudam por jogo: sem fonte listada, oferece os canais abertos que mais transmitem (ge tv, CazéTV) */
    if (!out.length && any) { YT.forEach(function (y) { if (/ge tv|CazéTV/.test(y.label)) { out.push({ label: y.label, url: y.url, tries: y.tries, streams: y.streams, cid: y.cid, generic: true }); } }); }
    return out;
  };

  /* vídeos de uma página do YouTube (busca ou /streams), sem depender do tipo de componente:
     junta, para cada id de vídeo, os textos próximos (título, canal, "AO VIVO"…). [{ id, text, live }] */
  /* o YouTube às vezes entrega o JSON da página escapado em hexadecimal (\x22 = aspas): desfaz antes de ler */
  Sp.unhex = function (html) {
    html = String(html || '');
    if (html.indexOf('\\x22') < 0) { return html; }
    return html.replace(/\\x([0-9a-fA-F]{2})/g, function (m, x) { return String.fromCharCode(parseInt(x, 16)); });
  };
  Sp.parseStreams = function (html) {
    html = Sp.unhex(html);
    var re = /"(?:videoId|contentId)":"([\w-]{11})"/g, hits = [], m, byId = {}, out = [];
    while ((m = re.exec(html))) {
      if (!hits.length || hits[hits.length - 1].id !== m[1]) { hits.push({ id: m[1], at: m.index }); }
    }
    hits.forEach(function (x, i) {
      var chunk = html.slice(x.at, Math.min(i + 1 < hits.length ? hits[i + 1].at : x.at + 4000, x.at + 4000));
      var e = byId[x.id];
      if (!e) { e = byId[x.id] = { id: x.id, raw: '' }; out.push(e); }
      e.raw += chunk;
    });
    out.forEach(function (e) {
      var texts = [], r = /"(?:text|content|label|simpleText)":"((?:[^"\\]|\\.)*)"/g, t;
      while ((t = r.exec(e.raw))) { var v = t[1]; try { v = JSON.parse('"' + v + '"'); } catch (er) { /* mantém */ } texts.push(v); }
      e.text = texts.join(' | ');
      /* ao vivo de verdade = selo AO VIVO ou "N assistindo" (o título "AO VIVO: …" não vale: lives agendadas também têm); live ainda não iniciada
         (estreia/programada/aguardando) nunca conta */
      e.upcoming = /upcomingEventData|UPCOMING|Estr[eé]ia|Programad|Agendad|Aguardando|Come[cç]a em|Come[cç]ar[aá]|Scheduled|waiting/i.test(e.raw);
      e.live = !e.upcoming && /BADGE_STYLE_TYPE_LIVE_NOW|LIVE_NOW|BADGE_STYLE_LIVE|"style":"LIVE"|"iconType":"LIVE"|"(?:label|text|simpleText|content)":"AO VIVO"|\d[\d.,]*\s*(?:mil|mi)?\s+assistindo|\bwatching\b|assistindo agora/i.test(e.raw);
      delete e.raw;
    });
    return out;
  };

  /* feed RSS do canal (funciona sem navegador): [{ id, title, at }] */
  function xmlText(t) {
    return String(t || '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&amp;/g, '&');
  }
  Sp.parseFeed = function (xml) {
    var out = [], re = /<entry>([\s\S]*?)<\/entry>/g, m;
    xml = String(xml || '');
    while ((m = re.exec(xml))) {
      var id = /<yt:videoId>([\w-]{11})<\/yt:videoId>/.exec(m[1]), t = /<title>([\s\S]*?)<\/title>/.exec(m[1]), p = /<published>([^<]+)<\/published>/.exec(m[1]);
      if (id) { out.push({ id: id[1], title: xmlText(t && t[1]), at: p ? Date.parse(p[1]) || 0 : 0 }); }
    }
    return out;
  };
  Sp.channelId = function (html) {
    html = Sp.unhex(html);
    var m = /channel_id=(UC[\w-]{22})/.exec(html) || /"(?:channelId|externalId)":"(UC[\w-]{22})"/.exec(html) || /\/channel\/(UC[\w-]{22})/.exec(html);
    return m ? m[1] : null;
  };

  var GENERIC = { club: 1, city: 1, united: 1, real: 1, sporting: 1, team: 1, futebol: 1, football: 1, clube: 1 };
  /* nomes de seleções em português (a ESPN envia em inglês) — é o que aparece no app e o que casa com títulos de canais */
  var DISP = {"brazil": "Brasil", "germany": "Alemanha", "france": "França", "spain": "Espanha", "england": "Inglaterra", "italy": "Itália", "netherlands": "Holanda", "holland": "Holanda", "belgium": "Bélgica", "uruguay": "Uruguai", "paraguay": "Paraguai", "ecuador": "Equador", "mexico": "México", "united states": "Estados Unidos", "usa": "Estados Unidos", "japan": "Japão", "croatia": "Croácia", "switzerland": "Suíça", "denmark": "Dinamarca", "sweden": "Suécia", "norway": "Noruega", "poland": "Polônia", "czechia": "Tchéquia", "czech republic": "Tchéquia", "scotland": "Escócia", "wales": "País de Gales", "turkey": "Turquia", "turkiye": "Turquia", "serbia": "Sérvia", "greece": "Grécia", "austria": "Áustria", "ukraine": "Ucrânia", "south korea": "Coreia do Sul", "korea republic": "Coreia do Sul", "north korea": "Coreia do Norte", "morocco": "Marrocos", "egypt": "Egito", "senegal": "Senegal", "cameroon": "Camarões", "saudi arabia": "Arábia Saudita", "australia": "Austrália", "canada": "Canadá", "costa rica": "Costa Rica", "hungary": "Hungria", "romania": "Romênia", "slovakia": "Eslováquia", "slovenia": "Eslovênia", "albania": "Albânia", "georgia": "Geórgia", "ireland": "Irlanda", "republic of ireland": "Irlanda", "northern ireland": "Irlanda do Norte", "iceland": "Islândia", "finland": "Finlândia", "new zealand": "Nova Zelândia", "south africa": "África do Sul", "ivory coast": "Costa do Marfim", "cote d ivoire": "Costa do Marfim", "algeria": "Argélia", "tunisia": "Tunísia", "nigeria": "Nigéria", "ghana": "Gana", "iran": "Irã", "ir iran": "Irã", "qatar": "Catar", "panama": "Panamá", "jamaica": "Jamaica", "argentina": "Argentina", "colombia": "Colômbia", "chile": "Chile", "peru": "Peru", "bolivia": "Bolívia", "venezuela": "Venezuela", "portugal": "Portugal", "russia": "Rússia", "bulgaria": "Bulgária", "israel": "Israel", "kosovo": "Kosovo", "luxembourg": "Luxemburgo", "north macedonia": "Macedônia do Norte", "montenegro": "Montenegro", "bosnia and herzegovina": "Bósnia e Herzegovina", "bosnia herzegovina": "Bósnia e Herzegovina", "china": "China", "china pr": "China", "india": "Índia", "indonesia": "Indonésia", "iraq": "Iraque", "jordan": "Jordânia", "uzbekistan": "Uzbequistão", "united arab emirates": "Emirados Árabes", "uae": "Emirados Árabes", "oman": "Omã", "bahrain": "Bahrein", "kuwait": "Kuwait", "thailand": "Tailândia", "vietnam": "Vietnã", "malaysia": "Malásia", "singapore": "Singapura", "philippines": "Filipinas", "honduras": "Honduras", "el salvador": "El Salvador", "guatemala": "Guatemala", "haiti": "Haiti", "cuba": "Cuba", "trinidad and tobago": "Trinidad e Tobago", "curacao": "Curaçao", "cape verde": "Cabo Verde", "cabo verde": "Cabo Verde", "dr congo": "RD Congo", "congo dr": "RD Congo", "mali": "Mali", "burkina faso": "Burkina Faso", "angola": "Angola", "mozambique": "Moçambique", "zambia": "Zâmbia", "gabon": "Gabão", "guinea": "Guiné", "benin": "Benim", "uganda": "Uganda", "kenya": "Quênia", "tanzania": "Tanzânia", "zimbabwe": "Zimbábue", "libya": "Líbia", "sudan": "Sudão", "ethiopia": "Etiópia", "estonia": "Estônia", "latvia": "Letônia", "lithuania": "Lituânia", "belarus": "Belarus", "moldova": "Moldávia", "armenia": "Armênia", "azerbaijan": "Azerbaijão", "kazakhstan": "Cazaquistão", "cyprus": "Chipre", "malta": "Malta", "faroe islands": "Ilhas Faroé", "andorra": "Andorra", "san marino": "San Marino", "liechtenstein": "Liechtenstein", "gibraltar": "Gibraltar", "suriname": "Suriname", "guyana": "Guiana", "new caledonia": "Nova Caledônia", "tahiti": "Taiti", "fiji": "Fiji", "palestine": "Palestina", "syria": "Síria", "lebanon": "Líbano"};
  Sp.ptName = function (name) { var n = Sp.norm(name); return DISP[n] || name; };
  function teamWords(name) {
    var n = Sp.norm(name), l = n.split(' ').filter(function (w) { return w.length >= 4 && !GENERIC[w]; });
    if (DISP[n]) { l = l.concat(Sp.norm(DISP[n]).split(' ').filter(function (w) { return w.length >= 4; })); }
    return l;
  }
  /* entre as transmissões AO VIVO, a que cita os times do jogo (e, de preferência, é do canal pedido) */
  Sp.pickLive = function (html, g, chan, own) {
    var hw = teamWords(g.home.name), aw = teamWords(g.away.name), cn = chan ? Sp.norm(chan).replace(/ /g, '') : '', best = null, bs = 0;
    Sp.parseStreams(html).forEach(function (st) {
      if (!st.live) { return; }
      var t = ' ' + Sp.norm(st.text) + ' ';
      var has = function (ws) { return ws.some(function (w) { return t.indexOf(' ' + w) >= 0; }); };
      var sc = (has(hw) ? 2 : 0) + (has(aw) ? 2 : 0);
      if (!sc) { return; }
      if (cn && !own && t.replace(/ /g, '').indexOf(cn) < 0) { return; }   // só canal oficial: sem reações/watchalongs (na página do próprio canal os itens não repetem o nome dele)
      if (cn) { sc += 1; }
      if (sc > bs) { bs = sc; best = st; }
    });
    return best;
  };

  /* transmissão ao vivo que cita os DOIS times, de qualquer canal conhecido (reações/watchalongs ficam de fora); o canal pedido ganha desempate */
  var OFFICIAL = /ge ?tv|caze ?tv|tnt sports|sportynet|globo|sportv|espn|record|sbt|xsports|cbf|fifa|conmebol|uefa|band|nsports|dazn|premiere/;
  var NOISE = /react|reacao|watch ?along|assistindo (com|o jogo|junto)|narracao|narrando|comentando|simulacao|pes |efootball|fifa 2|ea fc|fc 2|fc ?26|game play|gameplay/;
  Sp.pickLiveAny = function (html, g, chan) {
    var hw = teamWords(g.home.name), aw = teamWords(g.away.name), cn = chan ? Sp.norm(chan).replace(/ /g, '') : '', best = null, bs = 0;
    Sp.parseStreams(html).forEach(function (st) {
      if (!st.live) { return; }
      var t = ' ' + Sp.norm(st.text) + ' ', tn = t.replace(/ /g, '');
      var has = function (ws) { return ws.some(function (w) { return t.indexOf(' ' + w) >= 0; }); };
      if (!has(hw) || !has(aw) || NOISE.test(t) || !OFFICIAL.test(t.replace(/ +/g, ' ').replace(/ tv/g, 'tv').trim() + ' ' + tn)) { return; }
      var sc = 4 + (cn && tn.indexOf(cn) >= 0 ? 2 : 0);
      if (sc > bs) { bs = sc; best = st; }
    });
    return best;
  };

  /* pelo feed: vídeo que cita os times (até 14 dias se citar os dois; até 12 h se citar um); resumos/gols perdem para a transmissão */
  Sp.pickFeed = function (xml, g, now) {
    var hw = teamWords(g.home.name), aw = teamWords(g.away.name), best = null, bs = 0;
    Sp.parseFeed(xml).forEach(function (st) {
      if (st.at && (st.at < now - 14 * 86400000 || st.at > now + 3600000)) { return; }
      var t = ' ' + Sp.norm(st.title) + ' ';
      var has = function (ws) { return ws.some(function (w) { return t.indexOf(' ' + w) >= 0; }); };
      var sc = (has(hw) ? 2 : 0) + (has(aw) ? 2 : 0);
      // transmissão pode ser agendada dias antes: se o vídeo é antigo, só vale citando os dois times
      if (!sc || (sc < 4 && st.at && st.at < now - 12 * 3600000)) { return; }
      if (/melhores momentos|gols |resumo|reapresentacao|replay|bastidores/.test(t)) { sc -= 1; }
      if (/ao vivo/.test(t)) { sc += 1; }
      if (sc > bs || (sc === bs && best && st.at > best.at)) { bs = sc; best = st; }
    });
    return best;
  };


  /* ---------- canais: cruza os jogos com a programação ---------- */

  var CAT_RE = /esport|sport|futebol|premiere|libertad|champions|copa|brasileir|conmebol|globo|jogos|combate|dazn|tnt|espn|caz[eé]|fifa|abertos?/i;
  var NAME_RE = /globo|sportv|espn|premiere|tnt|caz[eé]|band|record|sbt|max|prime|paramount|dazn|fox sports|combate|conmebol|nsports|fifa|tv brasil|disney|star\+|bein|sky sports|canal\+/i;

  /* escolhe, entre todos os canais, os que podem passar jogos (pela categoria ou pelo nome) */
  Sp.candidateChannels = function (channels, cats, limit) {
    var good = {};
    (cats || []).forEach(function (c) { if (CAT_RE.test(c.name || '')) { good[c.id] = 1; } });
    var out = channels.filter(function (ch) { return ch.epgId && (good[ch.cat] || NAME_RE.test(ch.name || '')); });
    return out.slice(0, limit || 160);
  };

  /* games: jogos a procurar; progs: { idDoCanal: [{title, desc, start, stop}] }; channels: lista de canais.
     Devolve { idDoJogo: [canal, ...] } (canal com o programa que combinou, melhores primeiro) */
  Sp.assign = function (games, channels, progs) {
    var res = {};
    games.forEach(function (g) {
      var from = g.start - 45 * 60000, to = g.start + 3 * 3600000, hits = [];
      channels.forEach(function (ch) {
        var list = progs[ch.id] || [], best = 0, prog = null, i;
        for (i = 0; i < list.length; i++) {
          var p = list[i];
          if (p.stop <= from || p.start >= to) { continue; }
          var sc = Sp.matchText(g, (p.title || '') + ' ' + (p.desc || ''));
          if (sc > best) { best = sc; prog = p; }
        }
        if (best) { hits.push({ ch: ch, score: best, prog: prog }); }
      });
      hits.sort(function (a, b) { return b.score - a.score; });
      if (hits.length) { res[g.league + ':' + g.id] = hits; }
    });
    return res;
  };

  return Sp;
});
