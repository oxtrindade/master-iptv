/* Teste de fumaça da interface em jsdom: login -> Início -> listas -> player -> detalhe -> série -> busca -> favoritos
   -> continuar assistindo -> configurações -> demo. A rede passa pelo proxy real (PalmServiceBridge simulado). */
var path = require('path');
var assert = require('assert');
var jsdom = require('jsdom');
var mock = require('./mock-server.js');
var proxyLib = require('../services/com.rodrigo.iptv.service/proxy.js');

var api = mock.create(), px = proxyLib.create('tok');
function listen(s) { return new Promise(function (r) { s.listen(0, '127.0.0.1', r); }); }
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

var syncKV = {}, syncSrv = null;
// servidor de sincronização falso: o próprio Worker, com KV em memória, atrás de um servidor HTTP local
function startSync() {
  return import('../worker/sync-worker.mjs').then(function (m) {
    var env = { SYNC: { get: async function (k) { return Object.prototype.hasOwnProperty.call(syncKV, k) ? syncKV[k] : null; }, put: async function (k, v) { syncKV[k] = v; } } };
    syncSrv = require('http').createServer(function (req, res) {
      var chunks = [];
      req.on('data', function (c) { chunks.push(c); });
      req.on('end', function () {
        var body = Buffer.concat(chunks).toString('utf8'), noBody = req.method === 'GET' || req.method === 'HEAD';
        m.default.fetch(new Request('http://sync.local' + req.url, { method: req.method, body: noBody ? undefined : body }), env).then(function (r) {
          return r.text().then(function (txt) {
            var hd = {}; r.headers.forEach(function (v, k) { hd[k] = v; });
            res.writeHead(r.status, hd); res.end(txt);
          });
        });
      });
    });
    return listen(syncSrv);
  });
}

// abre o app já configurado e com 2 perfis: tem de ir direto ao seletor de perfis (sem a abertura "Conectando…"), conectar por trás e entrar ao escolher
function bootWithProfiles(base, pport) {
  var vc2 = new jsdom.VirtualConsole();
  vc2.on('jsdomError', function () {});
  return jsdom.JSDOM.fromFile(path.join(__dirname, '../app/index.html'), {
    runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true, virtualConsole: vc2,
    beforeParse: function (w) {
      w.Element.prototype.getBoundingClientRect = function () { return { left: 0, top: 0, right: 100, bottom: 50, width: 100, height: 50 }; };
      w.HTMLMediaElement.prototype.play = function () { return Promise.resolve(); };
      w.HTMLMediaElement.prototype.pause = function () {};
      w.HTMLMediaElement.prototype.load = function () {};
      var mem = { 'iptv.cfg': JSON.stringify({ server: base, user: 'joao', pass: 'segredo' }),
        'iptv.profiles': JSON.stringify([{ id: 'p1', name: 'Perfil 1', color: 0 }, { id: 'p2', name: 'Ana', color: 1 }]) };
      Object.defineProperty(w, 'localStorage', { configurable: true, value: {
        getItem: function (k) { return Object.prototype.hasOwnProperty.call(mem, k) ? mem[k] : null; },
        setItem: function (k, v) { mem[k] = String(v); },
        removeItem: function (k) { delete mem[k]; }
      } });
      w.PalmServiceBridge = function () {
        var self = this;
        this.call = function () { setTimeout(function () { self.onservicecallback(JSON.stringify({ returnValue: true, port: pport, token: 'tok' })); }, 0); };
      };
    }
  }).then(function (dom) {
    var w = dom.window, d = w.document, $ = function (s) { return d.querySelector(s); };
    function until(fn, what) {
      var n = 0;
      return new Promise(function (res, rej) {
        (function tick() { if (fn()) { res(); } else if (++n > 150) { rej(new Error('timeout: ' + what)); } else { setTimeout(tick, 50); } })();
      });
    }
    return until(function () { return $('#profiles .pcard'); }, 'perfis na abertura').then(function () {
      assert.ok(!$('#profiles').classList.contains('hidden'), 'perfis visíveis');
      assert.ok($('#splash').classList.contains('hidden'), 'sem a animação Conectando…');
      assert.ok($('#profiles').classList.contains('pin'), 'animação de entrada dos perfis');
      $('#profiles .pcard').click();   // escolhe antes de terminar (ou logo depois de) conectar
      return until(function () { return $('#profiles').classList.contains('hidden') && $('.hubtab, .hubtile'); }, 'entra na Início depois de escolher o perfil');
    }).then(function () {
      assert.ok(!$('#loader') || $('#loader').classList.contains('hidden'), 'sem carregando preso');
      console.log('  ok   abertura: perfis direto, conecta por trás e entra ao escolher');
      w.close();
    });
  });
}

Promise.all([listen(api), listen(px), startSync()]).then(function () {
  var base = 'http://127.0.0.1:' + api.address().port, pport = px.address().port;
  var errors = [];
  var vc = new jsdom.VirtualConsole();
  // o jsdom carrega o iframe do trailer; com internet (CI) o script do YouTube roda dentro dele e falha (performance.timing) — não é do app
  vc.on('jsdomError', function (e) { if (!/mpegts|hls|Not implemented|Could not load iframe|responseStart/i.test(String(e.message))) { errors.push(e.message); } });

  return jsdom.JSDOM.fromFile(path.join(__dirname, '../app/index.html'), {
    runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true, virtualConsole: vc,
    beforeParse: function (w) {
      w.Element.prototype.getBoundingClientRect = function () { return { left: 0, top: 0, right: 100, bottom: 50, width: 100, height: 50 }; };
      w.HTMLMediaElement.prototype.play = function () { return Promise.resolve(); };
      // jsdom com file:// tem origem opaca (sem localStorage): usa um armazenamento em memória
      var mem = {};
      Object.defineProperty(w, 'localStorage', { configurable: true, value: {
        getItem: function (k) { return Object.prototype.hasOwnProperty.call(mem, k) ? mem[k] : null; },
        setItem: function (k, v) { mem[k] = String(v); },
        removeItem: function (k) { delete mem[k]; }
      } });
      w.HTMLMediaElement.prototype.pause = function () {};
      w.HTMLMediaElement.prototype.load = function () {};
      w.PalmServiceBridge = function () {
        var self = this;
        this.call = function () { setTimeout(function () { self.onservicecallback(JSON.stringify({ returnValue: true, port: pport, token: 'tok' })); }, 0); };
      };
    }
  }).then(function (dom) {
    var w = dom.window, d = w.document;
    var $ = function (s) { return d.querySelector(s); }, $$ = function (s) { return [].slice.call(d.querySelectorAll(s)); };
    function key(code) { d.dispatchEvent(new w.KeyboardEvent('keydown', { keyCode: code, bubbles: true, cancelable: true })); }
    // navega pelo menu inicial: volta ao menu (se preciso) e abre a seção
    function go(sec) {
      while (!$('.hubtab[data-sec]') && $('.backbtn')) { $('.backbtn').click(); } // a busca de seção volta primeiro à seção, depois ao menu
      if (sec === 'home') { return; }
      if (sec === 'settings') { $('.menubtn').click(); $('.drawer-settings').click(); return; } // Configurações ficam no menu lateral
      $('[data-sec="' + sec + '"]').click();
    }
    function waitFor(fn, label) {
      var t0 = Date.now();
      return (function loop() {
        var v; try { v = fn(); } catch (e) { v = false; }
        if (v) { return Promise.resolve(v); }
        if (Date.now() - t0 > 6000) { return Promise.reject(new Error('timeout: ' + label + ' | detail: ' + ($('#detail') ? $('#detail').textContent.slice(0, 300) : ''))); }
        return sleep(25).then(loop);
      })();
    }
    var step = function (n) { console.log('  ok   ' + n); };
    var video = $('#video'), vt = 0, vd = NaN;
    Object.defineProperty(video, 'currentTime', { get: function () { return vt; }, set: function (v) { vt = v; }, configurable: true });
    Object.defineProperty(video, 'duration', { get: function () { return vd; }, configurable: true });

    return waitFor(function () { return $('.login') && w.Weather; }, 'login').then(function () {
      // clima falso (a rede real não é usada nos testes)
      var wxCalls = [];
      w.Weather.init(function (u) {
        wxCalls.push(u);
        if (/geocoding/.test(u)) { return Promise.resolve(JSON.stringify({ results: [{ name: 'Campinas', admin1: 'São Paulo', country_code: 'BR', latitude: -22.9, longitude: -47.06 }] })); }
        return Promise.resolve(JSON.stringify({ current: { temperature_2m: 24.4, apparent_temperature: 25, weather_code: 2, is_day: 1 },
          daily: { temperature_2m_min: [17.2], temperature_2m_max: [28.6] } }));
      });
      w.Sports.setBase(base + '/espn');   // placares simulados (a Início já pede os jogos de hoje)
      var inputs = $$('.login input');
      assert.strictEqual(inputs.length, 3);
      inputs[0].value = base; inputs[1].value = 'joao'; inputs[2].value = 'errada';
      $('.btn.primary').click();
      return waitFor(function () { return /inválidos/.test($('.err') ? $('.err').textContent : ''); }, 'erro de login');
    }).then(function () {
      var inputs = $$('.login input');
      assert.deepStrictEqual(inputs.map(function (i) { return i.value; }), [base, 'joao', 'errada'], 'campos preservados');
      step('erro de login mantém os dados nos campos');
      inputs[2].value = 'segredo';
      $('.btn.primary').click();
      return waitFor(function () { return $$('.hubtab').length === 5; }, 'menu inicial');
    }).then(function () {
      assert.deepStrictEqual($$('.hubtab').map(function (e) { return e.textContent; }), ['Início', 'TV ao vivo', 'Filmes', 'Séries', 'Esportes']);
      assert.ok($('.hubtab.focus') || $('.herobtns .focus'), 'foco no menu ou no banner');
      w.__pvTest = true;
      w.localStorage.setItem('iptv.tmdbkey', JSON.stringify('k'));   // só dublado: o trailer vem do TMDB
      w.Tmdb.findId = function () { return Promise.resolve(5); };
      w.Tmdb.trailer = function (kind, id, key, dub) { return Promise.resolve(dub ? 'dQw4w9WgXcQ' : ''); };   // prefere dublado
      w.Tmdb.trending = function () { return Promise.reject(new Error('sem rede no teste')); };
      return waitFor(function () { return $('.herotitle') && $('.herotitle').textContent; }, 'banner de destaque');
    }).then(function () {
      assert.ok(/Filme Teste/.test($('.herotitle').textContent), 'banner mostra um destaque do catálogo');
      assert.ok($('.herobtns .btn.primary') && /Assistir/.test($('.herobtns .btn.primary').textContent) && $('.herobtns .btn:not(.primary)'), 'banner com Assistir e Mais informações');
      step('home: banner de destaque');
      return waitFor(function () { var v = $('.herovid.ytv'); return v && v.getAttribute('src'); }, 'trailer no banner');
    }).then(function () {
      assert.ok(/(youtube\.com\/embed\/|\/yt\?t=tok&id=)(dQw4w9WgXcQ|abcdefghijk)/.test($('.herovid').getAttribute('src')), 'trailer (página do player via proxy local) começa logo no banner: ' + $('.herovid').getAttribute('src'));
      step('banner: trailer mudo após alguns segundos');
      d.body.classList.add('tv');
      if ($$('.herodot').length < 2) { d.body.classList.remove('tv'); return; }
      var t0 = $('.herotitle').textContent;
      w.Nav.focus($('[data-k="hero-info"]'));
      key(39);   // TV: ▶ em qualquer botão passa ao próximo destaque (foco fica no botão)
      return waitFor(function () { return $('.herotitle').textContent !== t0 && $('[data-k="hero-info"]') && $('[data-k="hero-info"]').classList.contains('focus'); }, 'TV: ▶ troca o destaque do banner').then(function () {
        key(37);   // ◀ volta
        return waitFor(function () { return $('.herotitle').textContent === t0; }, 'TV: ◀ volta ao destaque anterior');
      }).then(function () { d.body.classList.remove('tv'); step('banner (TV): ◀ ▶ trocam o destaque'); });
    }).then(function () {
      assert.ok(!$('.side'), 'sem barra lateral');
      assert.ok(!$('.hub-links') && !$$('.hub-links .btn').length, 'sem botões de atalho embaixo (Buscar/Configurações vão no topo)');
      assert.ok(!$$('.hrow-title').some(function (t) { return t.textContent === 'Favoritos'; }), 'sem favoritos: a fileira não aparece');
      var hdKids = [].slice.call($('.sechead').children).map(function (c) { return c.className.replace(/\bf\b/, '').replace(/\bfocus\b/, '').replace(/\s+/g, ' ').trim(); });
      assert.deepStrictEqual(hdKids, ['iconbtn menubtn', 'brand', 'avatar'], 'topo: menu à esquerda, nome no centro, perfil à direita: ' + hdKids.join(' | '));
      assert.strictEqual($('.sechead .brand').textContent, 'MASTER IPTV', 'nome do app no centro');
      assert.ok(!$('.sechead .wx') && !$('.sechead .clock') && !$('.sechead .usub'), 'clima/relógio/validade não ficam no topo');
      assert.ok($('.drawer').classList.contains('hidden'), 'menu lateral começa fechado');
      assert.ok($('.drawer .wx') && $('.drawer .clock') && $('.drawer .drawer-settings'), 'clima, relógio e Configurações dentro do menu lateral');
      step('menu inicial: TV ao vivo / Filmes / Séries');
      return waitFor(function () { return $('.wx-t') && /24°/.test($('.wx-t').textContent); }, 'clima');
    }).then(function () {
      assert.ok(/Taubaté/.test($('.wx-c').textContent), 'cidade padrão');
      assert.ok(/17° \/ 29°/.test($('.wx-r').textContent) && /Parcialmente/.test($('.wx-r').textContent), $('.wx-r').textContent);
      $('.menubtn').click();
      assert.ok(!$('.drawer').classList.contains('hidden'), 'hambúrguer abre o menu lateral');
      assert.ok($('.drawer-settings').classList.contains('focus'), 'foco em Configurações dentro do menu');
      key(461);
      assert.ok($('.drawer').classList.contains('hidden'), 'Voltar fecha o menu lateral (sem sair do app)');
      assert.ok($('.menubtn').classList.contains('focus'), 'foco volta ao hambúrguer');
      step('menu lateral: abre, mostra clima/Configurações e fecha com Voltar');
      step('clima na home (24°, mín/máx, cidade)');
      go('live');
      return waitFor(function () { return $$('.cat').length === 4 && $$('.row').length === 1; }, 'ao vivo');
    }).then(function () {
      assert.strictEqual($$('.card').length, 0, 'ao vivo só tem canais');
      return waitFor(function () { return /Jornal da Noite/.test($('.row .epg').textContent); }, 'epg na lista');
    }).then(function () {
      assert.ok($('.row .epgbar.on'), 'barra de progresso do programa');
      assert.ok(/^\d\d:\d\d–\d\d:\d\d  Jornal da Noite/.test($('.row .epg').textContent), 'horário início–fim: ' + $('.row .epg').textContent);
      assert.ok(/^A seguir  \d\d:\d\d  Cinema da Madrugada/.test($('.row .epgnext').textContent), 'próximo programa: ' + $('.row .epgnext').textContent);
      assert.ok($$('.cat .ct').every(function (e) { return !/^Canais\s*\|/.test(e.textContent); }), 'categorias sem o prefixo "Canais |"');
      assert.ok($$('.cat .ct').some(function (e) { return e.textContent === '⚽ Esportes'; }), 'nome limpo da categoria: ' + $$('.cat .ct').map(function (e) { return e.textContent; }).join(' | '));
      step('EPG do canal aparece na lista (horário + próximo) e categorias sem prefixo');
      assert.ok(/TV ao vivo/.test($('.sectitle').textContent));
      $$('.cat')[2].click();
      return waitFor(function () { return $$('.row').length === 3; }, 'cat esportes');
    }).then(function () {
      step('categorias ao vivo');
      $$('.cat')[3].click();
      return waitFor(function () { return $$('.row .epg.none').length >= 1; }, 'canal sem EPG');
    }).then(function () {
      assert.strictEqual($('.row .epg.none').textContent, 'Sem programação', 'canal sem EPG mostra texto discreto');
      step('canal sem EPG: "Sem programação"');
      $$('.cat')[2].click();
      return waitFor(function () { return $$('.row').length === 3; }, 'volta a esportes');
    }).then(function () {
      // guia de TV em grade
      $('[data-k="guide"]').click();
      return waitFor(function () { return $$('.grow').length === 3 && $$('.gpr:not(.gwait)').length >= 2; }, 'guia: canais com programação');
    }).then(function () {
      assert.ok(/Guia de TV/.test($('.sectitle').textContent), 'título Guia de TV');
      var blk = $$('.gpr:not(.gwait)')[0];
      w.Nav.focus(blk);
      assert.ok(/Jornal da Noite|Palmeiras|Cinema/.test($('.gdtitle').textContent), 'detalhe do programa em foco: ' + $('.gdtitle').textContent);
      assert.ok(/·/.test($('.gdchan').textContent), 'canal e horário no detalhe');
      assert.strictEqual($$('.gtick').length, 6, 'janela de 3 h com marcas de 30 min');
      $('[data-k="g-next"]').click();
      assert.ok($$('.gtick')[0].textContent !== '', 'janela avança sem quebrar');
      step('guia de TV: grade, detalhe e janela de horário');
      // OK em um canal toca numa janela ao lado (mini player) sem sair do guia; OK de novo no mesmo canal amplia
      $$('.gch')[0].click();
      assert.ok($('#player').classList.contains('mini') && $$('.grow').length === 3, 'canal toca ao lado, guia continua na tela');
      $$('.gch')[0].click();
      assert.ok(!$('#player').classList.contains('mini'), 'OK de novo no mesmo canal amplia');
      key(27);
      assert.ok($('#player').classList.contains('mini'), 'Voltar volta ao mini player ao lado do guia');
      $('.backbtn').click();
      return waitFor(function () { return $$('.row').length === 3; }, 'volta do guia para a lista de canais');
    }).then(function () {
      $$('.row')[0].click();
      return waitFor(function () { return !$('#player').classList.contains('hidden') && $('#video').getAttribute('src'); }, 'player live');
    }).then(function () {
      assert.ok(/102\.m3u8$/.test($('#video').getAttribute('src')));
      key(38);   // ▲ abre o guia por cima, o canal segue tocando
      return waitFor(function () { return !$('#pguide').classList.contains('hidden') && $$('#pguide .grow').length >= 2; }, 'guia dentro do player');
    }).then(function () {
      assert.ok(/102\.m3u8$/.test($('#video').getAttribute('src')), 'o canal continua tocando com o guia aberto');
      assert.ok($('#pguide .gdetail') && $('#pguide .gclose'), 'guia com detalhe e botão Voltar ao canal');
      key(461);
      assert.ok($('#pguide').classList.contains('hidden') && !$('#player').classList.contains('hidden'), 'Voltar fecha só o guia e segue no player');
      key(38);
      return waitFor(function () { return $$('#pguide .gch').length >= 2; }, 'guia reaberto');
    }).then(function () {
      $$('#pguide .gch')[1].click();   // escolhe outro canal no guia
      return waitFor(function () { return /103\.m3u8$/.test($('#video').getAttribute('src') || '') && $('#pguide').classList.contains('hidden'); }, 'troca de canal pelo guia');
    }).then(function () {
      key(33);   // CH+ continua trocando de canal
      return waitFor(function () { return !/103\.m3u8$/.test($('#video').getAttribute('src') || ''); }, 'zap com CH+');
    }).then(function () {
      key(34);
      return waitFor(function () { return /103\.m3u8$/.test($('#video').getAttribute('src') || ''); }, 'zap com CH-');
    }).then(function () {
      step('player ao vivo: guia por cima (▲), troca de canal pelo guia e CH+/CH−');
      // ao vivo não tem "Áudio e legenda": só o Guia de TV no menu de baixo
      key(404);
      assert.ok($('#tracks').classList.contains('hidden'), 'tecla verde não abre áudio/legenda no ao vivo');
      assert.ok($('#osd-tracks').classList.contains('hidden') && !$('#osd-guide').classList.contains('hidden'), 'menu do ao vivo: só Guia de TV');
      step('ao vivo sem áudio e legenda');
      key(27);
      assert.ok($('#player').classList.contains('hidden') && !$('#player').classList.contains('mini') && !d.body.classList.contains('mini-on'), 'Voltar fecha o vídeo (sem mini player no app)');
      assert.ok(!$('#app').classList.contains('hidden') && w.Nav.current(), 'lista visível e com foco');
      step('Voltar no player sai do vídeo');
      go('live');
      return waitFor(function () { return $$('.row').length > 0; }, 'canais de novo').then(function () {
        $$('.row')[0].click();
        return waitFor(function () { return !$('#player').classList.contains('hidden'); }, 'player de novo');
      });
    }).then(function () {
      key(27);
      assert.ok($('#player').classList.contains('hidden') && !$('#player').classList.contains('mini'), 'Voltar fecha o player');
      go('movie');
      return waitFor(function () { return $$('.card').length === 1; }, 'filmes');
    }).then(function () {
      var cd = $$('.card')[0];
      w.Nav.focus(cd);
      return waitFor(function () { return cd.querySelector('.cardvid.ytv') && cd.querySelector('.cardvid.ytv').getAttribute('src'); }, 'trailer no card').then(function () {
        w.Nav.focus($$('.f').filter(function (x) { return x !== cd; })[0]);
        return waitFor(function () { return !cd.querySelector('.cardvid'); }, 'prévia do card para ao mover o foco');
      }).then(function () { step('card: trailer ao segurar o foco, para ao sair'); });
    }).then(function () {
      // TMDB simulado: elenco do filme e filmografia do ator
      w.localStorage.setItem('iptv.tmdbkey', JSON.stringify('k'));
      w.Tmdb.findId = function () { return Promise.resolve(77); };
      w.Tmdb.credits = function () { return Promise.resolve([{ id: 9, n: 'Ana Atriz', c: 'Maria', p: '' }, { id: 10, n: 'Beto Ator', c: 'Zé', p: '' }]); };
      w.Tmdb.person = function () { return Promise.resolve([{ t: 'Filme Teste', o: '', y: 0, k: 'movie' }, { t: 'Nao Existe', o: '', y: 0, k: 'movie' }]); };
      $$('.card')[0].click();
      return waitFor(function () { return !$('#detail').classList.contains('hidden') && /Assistir/.test($('#detail .btn.primary').textContent); }, 'detalhe filme');
    }).then(function () {
      return waitFor(function () { return /Um filme de teste/.test($('#detail .dplot').textContent); }, 'plot');
    }).then(function () {
      return waitFor(function () { return $$('#detail .cast').length === 2; }, 'elenco');
    }).then(function () {
      assert.ok(/Ana Atriz/.test($('#detail .cast').textContent) && /Maria/.test($('#detail .cast').textContent));
      $$('#detail .cast')[0].click();
      return waitFor(function () { return $$('#detail .agrid .card').length === 1; }, 'filmografia do ator');
    }).then(function () {
      assert.ok(/Ana Atriz/.test($('#detail .dtitle').textContent));
      $$('#detail .agrid .card')[0].click();
      return waitFor(function () { return $('#detail .dtitle') && /Filme Teste/.test($('#detail .dtitle').textContent) && /Assistir/.test($('#detail .btn.primary').textContent); }, 'volta ao filme pelo ator');
    }).then(function () {
      key(27); // volta para a página do ator
      assert.ok(/Ana Atriz/.test($('#detail .dtitle').textContent), 'Voltar volta ao ator');
      key(27); // volta para o filme
      assert.ok(/Filme Teste/.test($('#detail .dtitle').textContent), 'Voltar volta ao filme');
      assert.ok(!$('#detail').classList.contains('hidden'));
      step('elenco + filmografia do ator');
      step('filmes + detalhe com sinopse');
      // celular: a tela do filme mostra o trailer ao fundo (só Wi-Fi: dados móveis não tocam)
      return waitFor(function () { var v = $('#detail .bg .ytv'); return v && v.getAttribute('src'); }, 'trailer na tela do filme (celular)');
    }).then(function () {
      assert.ok(/(youtube\.com\/embed\/|\/yt\?t=tok&id=)dQw4w9WgXcQ/.test($('#detail .bg .ytv').getAttribute('src')), 'trailer certo no fundo do detalhe');
      step('celular: trailer ao fundo da tela do filme');
      $('#detail .btn.primary').click();
      assert.ok(/501\.mkv$/.test($('#video').getAttribute('src')));
      vd = 3600; vt = 600; // simula 10 min assistidos de 1h
      key(27); assert.ok($("#player").classList.contains("hidden"), "filme: Voltar sai do vídeo");
      assert.ok($('#player').classList.contains('hidden'));
      assert.ok(!$('#detail').classList.contains('hidden'), 'volta ao detalhe');
      assert.ok(/Continuar/.test($('#detail .btn.primary') ? $('#detail').textContent : ''), 'botão vira Continuar');
      key(27);
      assert.ok($('#detail').classList.contains('hidden'));
      go('series');
      return waitFor(function () { return $$('.card').length === 1; }, 'series');
    }).then(function () {
      $$('.card')[0].click();
      return waitFor(function () { return $$('#detail .chip').length === 2 && $$('#detail .ep').length === 2; }, 'episodios');
    }).then(function () {
      assert.deepStrictEqual($$('#detail .ep .en').map(function (e) { return e.textContent; }), ['E1', 'E2']);
      $$('#detail .ep')[0].click();
      assert.ok(/7001\.mp4$/.test($('#video').getAttribute('src')));
      step('séries -> temporadas -> episódio');
      // episódios: menu de baixo com anterior/próximo, e CH+/CH- (sem botões coloridos)
      var vsrc = function () { return $('#video').getAttribute('src'); };
      // áudio e legenda: faixas expostas pelo player (simuladas) + tecla verde
      var vid = $('#video'), aud = [{ label: '', language: 'por', enabled: true }, { label: 'Dolby 5.1', language: 'eng', enabled: false }];
      Object.defineProperty(vid, 'audioTracks', { value: aud, configurable: true });
      var tt = vid.textTracks;
      vid.dispatchEvent(new w.Event('loadedmetadata'));
      key(404);
      assert.ok(!$('#tracks').classList.contains('hidden'), 'painel abre com a tecla verde');
      assert.deepStrictEqual($$('#tracks .topt .t-lbl').map(function (e) { return e.textContent; }), ['Português', 'Inglês · Dolby 5.1']);
      assert.ok(/não traz legendas/.test($('#tracks').textContent), 'sem legendas: aviso');
      $$('#tracks .topt')[1].click();
      assert.deepStrictEqual(aud.map(function (t) { return t.enabled; }), [false, true], 'troca o áudio');
      key(27);
      assert.ok($('#tracks').classList.contains('hidden') && !$('#player').classList.contains('hidden'), 'Voltar fecha só o painel');
      step('áudio e legenda: painel, troca de faixa, Voltar fecha só o painel');
      vt = 0; vd = NaN;   // sem duração: trocar de episódio não grava ponto de "continuar assistindo" neste teste
      assert.ok($('#osd-prevep').classList.contains('hidden') && !$('#osd-nextep').classList.contains('hidden'), 'primeiro episódio: só "próximo"');
      assert.ok(/E2/.test($('#osd-nextep').textContent), 'botão diz qual é o próximo: ' + $('#osd-nextep').textContent);
      $('#osd').classList.add('hidden');
      key(40);
      assert.ok($('#osd-bar').classList.contains('focus') && !$('#osd-tracks').classList.contains('focus'), 'baixo: menu abre na linha do tempo');
      key(38);
      assert.ok($('#osd-tracks').classList.contains('focus'), 'cima: vai para Áudio e legenda');
      key(39);
      assert.ok($('#osd-nextep').classList.contains('focus') && !$('#osd-tracks').classList.contains('focus'), '→ move para "Próximo episódio"');
      key(13);
      assert.ok(/7002\.mp4$/.test(vsrc()), 'OK em "Próximo episódio" toca o E2: ' + vsrc());
      assert.ok(!$('#osd-prevep').classList.contains('hidden') && /E1/.test($('#osd-prevep').textContent), 'agora aparece "Anterior"');
      key(33);
      assert.ok(/7101\.mkv$/.test(vsrc()) && $('#osd-nextep').classList.contains('hidden'), 'CH+ avança (T2 E1) e some o "próximo" no último');
      key(34);
      key(34);
      assert.ok(/7001\.mp4$/.test(vsrc()), 'CH- volta: ' + vsrc());
      key(34);
      assert.ok(/7001\.mp4$/.test(vsrc()), 'no primeiro não recua');
      // lista de episódios dentro do player
      $('#osd').classList.add('hidden');
      key(40); key(38); key(37);
      assert.ok($('#osd-eps').classList.contains('focus'), '← de Áudio e legenda vai para "Episódios"');
      $('#osd-eps').click();   // toque (celular)
      assert.ok(!$('#tracks').classList.contains('hidden') && $$('#tracks .topt').length >= 1, 'toque em "Episódios" abre a lista');
      assert.ok($$('#tracks .t-seasons .btn').length === 2, 'botões de temporada: ' + $('#tracks').textContent);
      $$('#tracks .t-seasons .btn')[1].click();
      assert.ok($$('#tracks .topt').length === 1, 'T2 lista os episódios da temporada 2');
      $$('#tracks .topt')[0].click();
      assert.ok($('#tracks').classList.contains('hidden') && /7101\.mkv$/.test(vsrc()), 'clicar num episódio troca e fecha a lista: ' + vsrc());
      key(34); key(34);
      assert.ok(/7001\.mp4$/.test(vsrc()), 'volta ao E1 para os próximos passos: ' + vsrc());
      // "Próximo episódio" nos créditos (sem registro na base: últimos 40 s)
      vd = 2700; vt = 100; $('#video').dispatchEvent(new w.Event('timeupdate'));
      assert.ok($('#skipnext').classList.contains('hidden'), 'no meio do episódio não mostra "Próximo episódio"');
      vt = 2670; $('#video').dispatchEvent(new w.Event('timeupdate'));
      assert.ok(!$('#skipnext').classList.contains('hidden'), 'nos créditos mostra "Próximo episódio"');
      vt = 2673; $('#video').dispatchEvent(new w.Event('timeupdate'));
      assert.ok(/em [23]/.test($('#skipnext').textContent), 'contagem regressiva: ' + $('#skipnext').textContent);
      vt = 2676; $('#video').dispatchEvent(new w.Event('timeupdate'));
      assert.ok(/7002\.mp4$/.test(vsrc()), 'passados 5 s toca o E2 sozinho: ' + vsrc());
      key(34);
      vd = NaN; vt = 0;
      step('séries: próximo/anterior episódio (menu e CH+/CH-)');
      vd = 2700; vt = 10;
      $('#video').dispatchEvent(new w.Event('timeupdate'));
      assert.ok(!$('#skip-intro') && !$('#osd-top #osd-tracks') && !$('.osd-top #osd-tracks'), 'sem "Pular introdução" e sem o botão de áudio no topo');
      assert.ok($('.osd-info #osd-tracks'), '"Áudio e legenda" fica no menu de baixo');
      // cima e baixo abrem o menu inferior com "Áudio e legenda" destacado; OK abre o painel
      $('#osd').classList.add('hidden');
      key(40);
      assert.ok(!$('#osd').classList.contains('hidden') && $('#osd-bar').classList.contains('focus'), 'baixo abre o menu na linha do tempo');
      var t0 = vt; key(39);
      assert.ok(vt > t0 && $('#osd-bar').classList.contains('focus'), '→ na linha do tempo avança e mantém o menu: ' + t0 + ' → ' + vt);
      key(37);
      assert.ok(vt <= t0 + 0.01 && $('#osd-bar').classList.contains('focus'), '← na linha do tempo retrocede');
      $('#osd').classList.add('hidden');
      key(38);
      assert.ok(!$('#osd').classList.contains('hidden') && $('#osd-bar').classList.contains('focus'), 'cima também abre o menu (na linha do tempo)');
      key(38);
      assert.ok($('#osd-tracks').classList.contains('focus') && $('#tracks').classList.contains('hidden'), 'cima de novo vai para Áudio e legenda (sem abrir o painel direto)');
      key(13);
      assert.ok(!$('#tracks').classList.contains('hidden'), 'OK no menu abre áudio e legenda');
      key(27);
      key(39);
      assert.ok(!$('#osd-tracks').classList.contains('focus'), 'outra tecla tira o destaque do menu');
      var was = vt; key(13);
      assert.ok($('#tracks').classList.contains('hidden'), 'OK sem o menu aberto só pausa/continua');
      step('menu inferior: cima/baixo -> Áudio e legenda; sem Pular introdução');
      vt = 0; vd = NaN;
      key(27); key(27);
      go('home');
      return waitFor(function () { return $$('.hrow-title').map(function (e) { return e.textContent; }).indexOf('Continuar assistindo') >= 0; }, 'continuar assistindo');
    }).then(function () {
      assert.ok($('.hubtab'), 'voltou ao menu');
      var w0 = $('.card.cont .pbar .fill').getAttribute('style');
      assert.ok(/width:17%/.test(w0), 'barra de progresso ~17%: ' + w0);
      assert.ok(/50 min restantes/.test($('.card.cont .contsub').textContent), $('.card.cont .contsub').textContent);
      assert.ok($$('.hrow-title').map(function (e) { return e.textContent; }).indexOf('Canais recentes') < 0, 'sem canais recentes na Início');
      step('menu: Continuar assistindo (progresso), sem canais recentes');
      $('.card.cont').click(); // Continuar
      assert.ok(/501\.mkv$/.test($('#video').getAttribute('src')), 'src: ' + $('#video').getAttribute('src') + ' | ' + $('.card.cont').textContent);
      vt = 0; vd = NaN;
      key(27);
      go('live'); // a lupa saiu da home: a busca agora fica dentro de cada seção
      $$('.sechead .btn').filter(function (b) { return !b.classList.contains('backbtn'); })[0].click();
      return waitFor(function () { return $('#q'); }, 'busca');
    }).then(function () {
      $('#q').value = 'esporte';
      $('#q').focus();
      key(13);
      return waitFor(function () { return $$('.card').length === 2; }, 'resultados');
    }).then(function () {
      step('busca global');
      $$('.card')[0].classList.add('focus');
      key(403);
      assert.ok($$('.card')[0].classList.contains('isfav'), 'estrela aparece');
      // toque longo no segundo banner favorita
      var ev = new w.Event('touchstart', { bubbles: true });
      ev.touches = [{ clientX: 5, clientY: 5 }];
      $$('.card')[1].dispatchEvent(ev);
      return new Promise(function (r) { setTimeout(r, 800); });
    }).then(function () {
      assert.ok($$('.card')[1].classList.contains('isfav'), 'toque longo favorita');
      var ev2 = new w.Event('touchstart', { bubbles: true });
      ev2.touches = [{ clientX: 5, clientY: 5 }];
      $$('.card')[1].dispatchEvent(ev2);
      return new Promise(function (r) { setTimeout(r, 800); });
    }).then(function () {
      assert.ok(!$$('.card')[1].classList.contains('isfav'), 'toque longo desfavorita');
      step('toque longo');
      go('fav');
      return waitFor(function () { return $$('.card').length === 1; }, 'favoritos');
    }).then(function () {
      step('favoritos');
      $('.backbtn').click();
      return waitFor(function () { return $('.hubtab'); }, 'menu com favoritos');
    }).then(function () {
      var titles = $$('.hrow-title').map(function (t) { return t.textContent; });
      assert.ok(titles.indexOf('Favoritos') >= 0, 'com favoritos: fileira na home (' + titles.join(' | ') + ')');
      var row = $$('.hrow').filter(function (r) { return r.querySelector('.hrow-title').textContent === 'Favoritos'; })[0];
      assert.strictEqual(row.querySelectorAll('.card:not(.seeall)').length, 1, 'o favorito aparece na fileira');
    }).then(function () {
      var cd;
      d.body.classList.add('tv');
      cd = $$('.hrow .hlist > .card:not(.seeall)')[0];
      cd.querySelector('.poster')._it = { type: 'movie', id: 1, name: 'Filme Teste', url: 'http://x/a.mp4' };   // o favorito do teste é um canal: finge um filme
      w.Nav.focus(cd);
      return waitFor(function () { return cd.classList.contains('wide') && cd.querySelector('.wideov'); }, 'card largo ao parar o foco').then(function () {
        assert.ok(/Filme|Série/.test(cd.querySelector('.wideh').textContent), 'título no card largo');
        w.Nav.focus($('.hubtab'));
        return waitFor(function () { return !cd.classList.contains('wide') && !cd.querySelector('.wideov'); }, 'card volta ao normal ao sair');
      }).then(function () { d.body.classList.remove('tv'); step('fileira (TV): card em foco vira largo e volta ao normal'); });
    }).then(function () {
      var row = $$('.hrow').filter(function (r) { return r.querySelector('.hrow-title').textContent === 'Favoritos'; })[0];
      assert.ok(row.querySelector('.card.seeall'), 'Ver todos no fim da fileira');
      assert.ok(!$('.hub-links'), 'continua sem botão de atalho');
      row.querySelector('.card.seeall').click();
      return waitFor(function () { return $$('.card').length === 1 && $('.sectitle') && /Favoritos/.test($('.sectitle').textContent); }, 'ver todos abre a lista');
    }).then(function () {
      step('Favoritos na home como fileira (+ Ver todos), sem botão');
      (function () {
        var lst = [], i;
        for (i = 0; i < 6; i++) { lst.push({ type: 'movie', id: 'a' + i, name: 'Aventura ' + i, logo: 'x', cat: '1', added: i }); lst.push({ type: 'movie', id: 'd' + i, name: 'Drama ' + i, logo: 'x', cat: '2' }); lst.push({ type: 'movie', id: 't' + i, name: 'Terror ' + i, logo: 'x', cat: '3' }); lst.push({ type: 'movie', id: 'x' + i, name: 'Adulto ' + i, logo: 'x', cat: '4' }); }
        var g = w.__genreRows('movie', [{ id: '3', name: 'FILMES | TERROR' }, { id: '4', name: 'Filmes Adultos +18' }, { id: '2', name: 'Filmes - Drama' }, { id: '1', name: 'Aventura' }], lst);
        assert.strictEqual(g.map(function (r) { return r.title; }).join(','), 'Aventura,Drama,Terror', 'gêneros em ordem Netflix, sem adulto');
        assert.strictEqual(g[0].items[0].id, 'a5', 'mais novos primeiro');
      })();
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config');
    }).then(function () {
      var txt = $('.settings').textContent;
      assert.ok(/127\.0\.0\.1/.test(txt) && /joao/.test(txt));
      var ver = require('../app/appinfo.json').version;
      assert.ok(txt.indexOf('Versão do app') >= 0 && txt.indexOf(ver) >= 0, 'versão do app em Configurações deve ser a do appinfo.json (' + ver + ')');
      assert.strictEqual($$('.swrow').length, 2, 'só duas chaves (inclui conteúdo adulto): ' + $$('.swl').map(function (e) { return e.textContent; }).join(' | '));
      assert.ok(/conteúdo adulto/.test($('.settings').textContent) && !/canais SD|canais HD|filmes de cinema|trailer dublado|Modo leve/.test($('.settings').textContent), 'SD/HD/cinema/dublado/modo leve fora da tela');
      step('configurações');
      // ocultar SD / HD: a categoria "Filmes e séries 24h" tem Cine HD, Cine SD e Cine FHD
      w.__setOpt('hideSD', true); w.__setOpt('hideHD', true);
      $('.backbtn').click();
      go('live');
      return waitFor(function () { return $$('.cat').length === 4; }, 'ao vivo de novo');
    }).then(function () {
      $$('.cat')[3].click();
      return waitFor(function () { return $$('.row').length === 1; }, 'só o FHD sobra');
    }).then(function () {
      assert.ok(/Cine FHD/.test($('.row .name').textContent), 'FHD não é ocultado');
      step('ocultar canais SD e HD (FHD continua)');
      $('.backbtn').click();
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config 2');
    }).then(function () {
      w.__setOpt('hideSD', false); w.__setOpt('hideHD', false); // desliga os dois
      // cidade do clima
      $('#city').value = 'Campinas';
      $('#city').focus();
      key(13);
      return waitFor(function () { return $$('.cityres .btn').length === 1; }, 'resultado da cidade');
    }).then(function () {
      assert.ok(/Campinas — São Paulo/.test($('.cityres .btn').textContent));
      $('.cityres .btn').click();
      assert.ok(/Campinas/.test($('.settings').textContent), 'cidade atualizada');
      $('.backbtn').click();
      return waitFor(function () { return $('.wx-c') && /Campinas/.test($('.wx-c').textContent); }, 'clima da nova cidade');
    }).then(function () {
      step('cidade do clima editável nas configurações');
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config 3');
    }).then(function () {
      // sincronização entre aparelhos (Worker simulado em http://127.0.0.1)
      var surl = 'http://127.0.0.1:' + syncSrv.address().port;
      assert.ok($('#syncurl') && $('#synccode'), 'bloco Sincronização nas configurações');
      $('#syncurl').value = surl;
      $$('.settings .btn').filter(function (b) { return b.textContent === 'Gerar novo código'; })[0].click();
      return waitFor(function () { return Object.keys(syncKV).length === 1 && /Sincronizado/.test($('.settings').textContent); }, 'primeira sincronização');
    }).then(function () {
      var codeTxt = $('#synccode').value, stored = JSON.parse(syncKV[Object.keys(syncKV)[0]]);
      assert.ok(/^[A-Z2-9]{4}(-[A-Z2-9]{4}){3}$/.test(codeTxt), 'código gerado: ' + codeTxt);
      assert.ok(Object.keys(stored.fav).length >= 1 && Object.keys(stored.cont).length >= 1, 'enviou favoritos e continuar assistindo');
      assert.ok(/Para parear outro aparelho, digite lá: .+#/.test($('.settings').textContent), 'mostra o texto de pareamento');
      // outro aparelho marca um favorito e assiste algo; este recebe ao sincronizar
      stored.fav['movie:777'] = { type: 'movie', id: '777', name: 'Filme do Celular' };
      stored.favmeta['movie:777'] = { at: Date.now() + 5000 };
      stored.cont['m:777'] = { rk: 'm:777', kind: 'movie', item: { type: 'movie', id: '777', name: 'Filme do Celular' }, t: 600, d: 6000, at: Date.now() + 5000 };
      stored.resume['m:777'] = { t: 600, d: 6000, at: Date.now() + 5000 };
      syncKV[Object.keys(syncKV)[0]] = JSON.stringify(stored);
      $$('.settings .btn').filter(function (b) { return b.textContent === 'Sincronizar agora'; })[0].click();
      return waitFor(function () { return JSON.parse(w.localStorage.getItem('iptv.fav'))['movie:777']; }, 'favorito do outro aparelho chegou');
    }).then(function () {
      assert.ok(JSON.parse(w.localStorage.getItem('iptv.cont'))['m:777'], 'continuar assistindo do outro aparelho chegou');
      assert.ok(JSON.parse(w.localStorage.getItem('iptv.favmeta'))['movie:1'] || JSON.parse(w.localStorage.getItem('iptv.favmeta'))['movie:777'], 'favoritos têm data');
      step('sincronização: gerar código, enviar e receber do outro aparelho');
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config 4');
    }).then(function () {
      // 1.71.0: sempre abas no topo; a escolha de blocos grandes não existe mais
      assert.ok(!$$('.settings .btn').some(function (x) { return x.textContent === 'Blocos grandes' || x.textContent === 'Abas no topo'; }), 'sem escolha de estilo da Início');
      assert.ok($$('.hubtab').length === 0 || $$('.hubtab').length === 5, 'abas no topo');
      step('Início: sempre abas no topo');
      // proteção de tela: sem mexer, mostra as capas; qualquer tecla só fecha
      assert.ok($$('.settings .btn').some(function (x) { return x.textContent === '10 min'; }), 'opções da proteção de tela nas configurações');
      w.localStorage.setItem('iptv.screensaver', '0.02');
      w.__ssArm();
      return waitFor(function () { return $('#screensaver .sspo'); }, 'proteção de tela aparece');
    }).then(function () {
      assert.ok($('#screensaver .sst').textContent.length > 0, 'mostra o título da capa');
      var before = w.Nav.current();
      key(40);
      assert.ok(!$('#screensaver'), 'uma tecla fecha a proteção de tela');
      assert.strictEqual(w.Nav.current(), before, 'a tecla não navegou');
      w.localStorage.setItem('iptv.screensaver', '0');
      w.__ssArm();
    }).then(function () {
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config 6');
    }).then(function () {
      // Esportes: placares (fonte simulada), canal pela programação, meus times, filtro de amistosos
      w.Sports.setBase(base + '/espn');
      go('home');
      assert.ok($('[data-sec="sports"]'), 'Esportes aparece na Início');
      return waitFor(function () { return $('.sphome .spcard'); }, 'jogos na Início');
    }).then(function () {
      var hx = $('.sphome').textContent;
      assert.ok(/jogos de hoje/.test(hx) && /Palmeiras/.test(hx) && /Flamengo/.test(hx) && !/Brazil/.test(hx), 'fileira de jogos na Início (sem jogos de outros dias): ' + hx.slice(0, 120));
      assert.ok($$('.sphome .spcard')[0].classList.contains('live'), 'jogo ao vivo vem primeiro');
      $$('.sphome .spcard')[0].click();
      assert.ok($('.spscoreboard') && /Raphael Veiga/.test($('.sports').textContent), 'toque no jogo da Início abre o jogo');
      // o canal é procurado na programação depois de abrir: quando aparece, o foco já fica nele (só dar OK)
      return waitFor(function () { return $('.spplay') && w.Nav.current() === $('.spplay'); }, 'foco no botão do canal');
    }).then(function () {
      key(27);
      return waitFor(function () { return $$('.spcard').length >= 1; }, 'placares');
    }).then(function () {
      var txt = $('.sports').textContent;
      assert.ok(/Ao vivo agora/.test(txt) && /AO VIVO 67'/.test(txt) && /Palmeiras/.test(txt) && /Grêmio/.test(txt), 'jogo ao vivo com minuto: ' + txt.slice(0, 160));
      assert.ok(/Flamengo/.test(txt) && !/France/.test(txt), 'amistoso sem o Brasil fica de fora');
      assert.ok(/Brasileirão/.test(txt), 'agrupa por liga');
      return waitFor(function () { return /Canal Esporte 2/.test($('.spcard.live').textContent); }, 'canal do jogo na programação');
    }).then(function () {
      assert.ok(!$('.spwarn'), 'uma liga fora do ar não polui a tela');
      var gu = $('.spch.guess');
      assert.ok(gu && /Palpite: Premiere 3/.test(gu.textContent), 'jogo sem canal no guia: palpite com o Premiere sem guia');
      $('.spcard.live').click();
      assert.ok(/Raphael Veiga/.test($('.sports').textContent) && !/Posse de bola/.test($('.sports').textContent), 'gols; estatísticas começam ocultas');
      $('.spacc[data-k="acc:stats"]').click();
      assert.ok(/Posse de bola/.test($('.sports').textContent) && /55%/.test($('.sports').textContent), 'estatísticas abrem na sanfona');
      return waitFor(function () { return $('.spacc[data-k="acc:lineup"]'); }, 'escalação (sanfona)');
    }).then(function () {
      assert.ok($('.spacc[data-k="acc:lineup"]') && !$('.sppitch'), 'escalação começa oculta (sanfona)'); $('.spacc[data-k="acc:lineup"]').click(); assert.ok($$('.sppitch .spplayer').length === 22 && /4-3-3/.test($('.splnames').textContent), 'escalação abre com formação');
      var pl = $$('.spplay')[0];
      assert.ok(pl && /Canal Esporte 2/.test(pl.textContent), 'botão para assistir no canal');
      var fb = $$('.sports .btn').filter(function (b) { return /Seguir Palmeiras/.test(b.textContent); })[0];
      fb.click();
      assert.ok(/Seguindo Palmeiras/.test($('.sports').textContent) && JSON.parse(w.localStorage.getItem('iptv.sportteams'))['2029'], 'segue o time');
      key(27);
      assert.ok($('.spcard') && !$('.spback'), 'Voltar sai do jogo e volta à lista');
      assert.ok($('.spstar'), 'estrela no time seguido');
      $('.spcard.live').click();
      $$('.spplay')[0].click();
      assert.ok(!$('#player').classList.contains('hidden') && /103/.test($('#video').getAttribute('src')), 'assiste no canal: ' + $('#video').getAttribute('src'));
      key(413);
      assert.ok($('#player').classList.contains('hidden'));
      key(27);
      assert.ok($('.sphero') && /Palmeiras|Flamengo/.test($('.sphero').textContent) && $$('.sphdot').length >= 2, 'banner de destaque com os jogos de hoje');
      assert.ok($('.spcard .sprow').style.background !== undefined, 'cards com linhas de time');
      $('[data-k="tab:tables"]').click();
      return waitFor(function () { return $('.sptr:not(.head)'); }, 'tabela de classificação');
    }).then(function () {
      var tr = $$('.sptr:not(.head)');
      assert.ok(tr.length === 2 && /^1Palmeiras/.test(tr[0].textContent.replace(/\s+/g, '')) && /22$/.test(tr[0].textContent), 'tabela ordenada por posição: ' + tr[0].textContent);
      step('esportes: banner de destaque e aba Tabelas');
      $('[data-k="tab:teams"]').click();
      assert.ok($('.spchip.team') && /Palmeiras/.test($('.sports').textContent), 'Meus times mostra o time e o jogo');
      $('[data-k="tab:channels"]').click();
      assert.ok(/Canal Esporte 2/.test($('.sports').textContent), 'aba de canais lista o jogo com o canal');
      $('[data-k="tab:scores"]').click();
      $('[data-k="d:2"]').click();
      assert.ok(/Brasil/.test($('.sports').textContent) && !/Fran/.test($('.sports').textContent), 'amistoso do Brasil aparece em outro dia');
      step('esportes: placares, canal pela programação, seguir time, amistosos só do Brasil');
      go('home');
      assert.ok($('.hubtab, .hubtile'));
      assert.ok(!$('.spchips'), 'saiu da tela de esportes');
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config 7');
    }).then(function () {
      // perfis: criar, trocar, dados separados
      var favs0 = w.localStorage.getItem('iptv.fav');
      assert.ok(favs0 && Object.keys(JSON.parse(favs0)).length >= 1, 'perfil 1 tem favoritos');
      assert.ok(/Perfil 1/.test($('.settings').textContent), 'mostra o perfil atual');
      $$('.settings .btn').filter(function (b) { return b.textContent === 'Gerenciar perfis'; })[0].click();
      assert.ok(!$('#profiles').classList.contains('hidden'), 'seletor de perfis abre');
      $('#profiles .padd').click();
      $('#profiles input').value = 'Ana';
      assert.ok($$('#profiles .aicon').length >= 12, 'editor oferece ícones de avatar');
      w.Nav.focus($$('#profiles .aicon')[2]);
      $$('#profiles .aicon')[2].click();
      // perfil novo: escolher o avatar já cria o perfil e volta à seleção de perfis
      assert.ok(!$('#profiles .aicon') && /Quem está assistindo|Gerenciar perfis/.test($('#profiles').textContent), 'voltou à seleção de perfis');
      assert.strictEqual($$('#profiles .pcard').length, 3, 'dois perfis + adicionar');
      assert.ok($$('#profiles .pcard')[1].querySelector('svg'), 'o perfil salvo mostra o ícone em vez da inicial');
      // perfil existente: escolher o avatar já grava, sem apertar "Salvar"
      $$('#profiles .pcard')[1].click();   // em "Gerenciar": abre a edição
      var ic5 = $$('#profiles .aicon')[5];
      assert.ok(ic5, 'edição do perfil Ana abriu');
      ic5.click();
      assert.ok(!$('#profiles .aicon'), 'escolher o avatar volta à seleção de perfis');
      var saved = w.JSON.parse(w.localStorage.getItem('iptv.profiles')).filter(function (x) { return x.name === 'Ana'; })[0];
      assert.ok(saved && saved.icon === ic5._k, 'avatar gravado ao escolher, sem Salvar: ' + (saved && saved.icon) + ' / ' + ic5._k);
      $$('#profiles .btn').filter(function (b) { return b.textContent === 'Concluído'; })[0].click();
      $$('#profiles .pcard')[1].click(); // entra no perfil Ana
      assert.ok($('#profiles').classList.contains('hidden') && $('.hubtab'), 'entrou no menu do novo perfil');
      assert.strictEqual(Object.keys(w.JSON.parse(w.localStorage.getItem('iptv.' + w.JSON.parse(w.localStorage.getItem('iptv.curprof')) + '.fav') || '{}')).length, 0, 'favoritos separados');
      assert.ok($('.avatar svg') && $('.avatar').textContent === '', 'avatar mostra o ícone escolhido no perfil');
      $('.avatar').click();
      $$('#profiles .pcard')[0].click(); // volta ao perfil 1
      assert.strictEqual(w.JSON.parse(w.localStorage.getItem('iptv.curprof')), 'p1');
      assert.strictEqual(w.localStorage.getItem('iptv.fav'), favs0, 'favoritos do perfil 1 intactos');
      step('perfis: criar, trocar e manter dados separados');
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config 4');
    }).then(function () {
      // editar servidor: abre o login já preenchido, com Cancelar
      $$('.settings .btn').filter(function (b) { return b.textContent === 'Editar servidor'; })[0].click();
      return waitFor(function () { return $('.login'); }, 'editar servidor');
    }).then(function () {
      assert.strictEqual($$('.login input')[1].value, 'joao');
      assert.strictEqual($$('.login .btn').length, 3, 'Entrar + Entrar pelo celular + Cancelar');
      $$('.login .btn')[2].click(); // Cancelar
      return waitFor(function () { return $('.settings .sgroup'); }, 'volta às configurações');
    }).then(function () {
      step('editar servidor (preenchido, com cancelar)');
      $$('.settings .btn').filter(function (b) { return /Trocar conta/.test(b.textContent); })[0].click(); // Trocar conta / Sair
      return waitFor(function () { return $('.login'); }, 'logout');
    }).then(function () {
      assert.strictEqual($$('.login input')[1].value, 'joao', 'logout mantém usuário');
      assert.strictEqual($$('.login .btn').length, 2, 'login: Entrar + Entrar pelo celular (sem modo demonstração)');
      assert.ok(/MASTER IPTV/.test($('.login .logo').textContent));
      $$('.login .btn')[1].click();
      assert.ok($('.login.pair .qrbox img') && /^data:image\/gif/.test($('.login.pair .qrbox img').src), 'entrar pelo celular mostra o QR Code');
      assert.ok(/^[A-Z2-9]{4}(-[A-Z2-9]{4}){3}$/.test($('.paircode').textContent), 'e o código');
      $$('.login.pair .btn')[0].click();
      assert.ok($('.login:not(.pair)'), 'Voltar do QR volta ao login');

      step('logout volta ao login (sem demonstração, nome Master IPTV) + QR Code');
      mock.many = true;   // a partir daqui o catálogo de filmes é grande (testa Filmes por gênero)
      // http x https: o servidor de teste só fala http; digitar https:// deve cair sozinho em http:// e guardar o que funcionou
      $$('.login input')[0].value = base.replace('http://', 'https://');
      $$('.login input')[2].value = 'segredo';
      $('.btn.primary').click();
      return waitFor(function () { return $('.hubtab, .hubtile'); }, 'login com https digitado');
    }).then(function () {
      assert.strictEqual(JSON.parse(w.localStorage.getItem('iptv.cfg')).server, base, 'guardou o endereço que funcionou (http)');
      assert.ok(/Servidor ajustado/.test($('#toast').textContent), 'avisa que ajustou o endereço');
      step('login: https digitado, servidor só http -> ajusta sozinho');
      return waitFor(function () {
        var c = JSON.parse(w.localStorage.getItem('iptv.spcache') || 'null');
        return c && Object.keys(c.days).length && Object.keys(c.chan).length && Object.keys(c.epg).length;
      }, 'jogos, canais e programação guardados no aparelho');
    }).then(function () {
      step('esportes: cache no aparelho (jogos, canais, programação)');
      // 2ª abertura: com o cache dos destaques o banner tem de aparecer na Início (regressão: ficava escondido)
      w.localStorage.setItem('iptv.herocache:movie,series', JSON.stringify([{ it: { type: 'movie', id: 'hc1', name: 'Filme Cache', logo: 'http://x/p.jpg', url: 'http://x/a.mp4' }, cont: null }]));
      go('home');
      assert.ok($('.hero:not(.hidden)'), 'banner aparece na hora com o cache');
      w.localStorage.removeItem('iptv.herocache:movie,series');
      return new Promise(function (r) { setTimeout(r, 500); }).then(function () {
        var f = $('.focus');
        assert.ok(f && f.getAttribute('data-k') === 'hero-play', 'banner vindo do cache: foco já cai no Assistir (trailer inicia): ' + (f && (f.getAttribute('data-k') || f.className)));
        step('Início: banner aparece a partir do cache, com o foco no Assistir');
      });
    }).then(function () {
      step('Início: banner (cache)');
      // Filmes por gênero (catálogo grande): banner de destaque com trailer, igual à Início
      w.__pvTest = true;
      w.Tmdb.findId = function () { return Promise.resolve(5); };
      w.Tmdb.trailer = function () { return Promise.resolve('dQw4w9WgXcQ'); };
      w.localStorage.setItem('iptv.tmdbkey', JSON.stringify('k'));
      go('home');
      $('[data-sec="movie"]').click();
      return waitFor(function () { return $$('.genrehome .gnrows .hrow').length >= 1; }, 'fileiras por gênero em Filmes').then(function () {
        assert.ok(!$('.genrehome .hero'), 'banner só na Início (Filmes/Séries não têm)');
        assert.ok($('.genrehome .hubtab'), 'menu no topo');
        step('Filmes: fileiras por gênero, sem banner');
        w.__itemSheet({ type: 'movie', id: 'zz1', name: 'Filme Folha', url: 'http://x/a.mp4' });
        assert.ok($('#isheet .isbtn'), 'folha de ações abre');
        assert.ok(/favoritos/.test($('#isheet .isbtn').textContent), 'folha: favoritar');
        $('#isheet .isbtn').click();
        assert.ok(!$('#isheet'), 'folha fecha ao escolher');
        mock.many = false;
        return sleep(2700);   // o aviso de "sair" de um Voltar anterior já venceu
      }).then(function () {
        // Voltar na Início com 2+ perfis: passa pela seleção de perfis antes do aviso de sair
        w.localStorage.setItem('iptv.profiles', JSON.stringify([{ id: 'p1', name: 'Perfil 1', color: 0 }, { id: 'p2', name: 'Ana', color: 1 }]));
        go('home');
        d.dispatchEvent(new w.KeyboardEvent('keydown', { keyCode: 27, bubbles: true, cancelable: true }));
        if ($('#profiles').classList.contains('hidden')) { d.dispatchEvent(new w.KeyboardEvent('keydown', { keyCode: 27, bubbles: true, cancelable: true })); }   // o 1º pode só subir ao banner
        assert.ok(!$('#profiles').classList.contains('hidden'), 'Voltar na Início abre a seleção de perfis');
        $('#profiles .pcard').click();
        assert.ok($('#profiles').classList.contains('hidden'), 'escolher o perfil volta ao app');
        w.localStorage.removeItem('iptv.profiles');
      });
    }).then(function () {
      assert.deepStrictEqual(errors, [], 'erros de script: ' + errors.join(' | '));
      return bootWithProfiles(base, pport);
    }).then(function () {
      console.log('UI ok');
    });
  });
}).then(function () { api.close(); px.close(); process.exit(0); }, function (e) {
  console.error('  FAIL ' + (e && e.stack || e)); try { console.error('  erros de página: ' + JSON.stringify(typeof errors !== 'undefined' ? errors : [])); } catch (x) {} process.exit(1);
});
